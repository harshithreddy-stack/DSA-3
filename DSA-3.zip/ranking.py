"""
Result Ranking and Custom DSA Sorting.

Time Complexity:
- Document Scoring: O(M) where M is the number of raw matches found.
- Result Sorting (Merge Sort): O(K log K) where K is the number of distinct matching documents.
Space Complexity: O(K) auxiliary space.

Core DSA Concept:
Raw matches mapped to documents are aggregated and scored using multiple relevance criteria:
1. Term Frequency (occurrences count)
2. Document Title Match bonus
3. Early position prominence (first occurrence offset)
4. Match density (matches relative to document length)

The scored results are sorted using a custom MergeSort implementation to demonstrate
DSA sorting algorithms.
"""

from typing import List, Dict, Any, Tuple
from .document_manager import Document


class ScoredDocument:
    """Represents a document with computed search score and highlighted snippets."""

    def __init__(
        self,
        document: Document,
        match_count: int,
        first_position: int,
        in_title: bool,
        score: float,
        snippets: List[str],
        positions: List[int]
    ):
        self.doc_id = document.doc_id
        self.title = document.title
        self.filename = document.filename
        self.match_count = match_count
        self.first_position = first_position
        self.in_title = in_title
        self.score = round(score, 2)
        self.snippets = snippets
        self.positions = positions

    def to_dict(self) -> Dict[str, Any]:
        return {
            "doc_id": self.doc_id,
            "title": self.title,
            "filename": self.filename,
            "match_count": self.match_count,
            "first_position": self.first_position,
            "in_title": self.in_title,
            "score": self.score,
            "snippets": self.snippets,
            "positions": self.positions
        }


def merge_sort_scored_docs(items: List[ScoredDocument]) -> Tuple[List[ScoredDocument], int]:
    """
    Custom DSA Merge Sort to sort scored documents in descending order of score.
    Returns (sorted_list, comparison_count).
    Complexity: O(K log K) time, O(K) space.
    """
    comparisons = 0

    def _merge(left: List[ScoredDocument], right: List[ScoredDocument]) -> List[ScoredDocument]:
        nonlocal comparisons
        result = []
        i = j = 0
        while i < len(left) and j < len(right):
            comparisons += 1
            # Sort descending: higher score comes first
            if left[i].score >= right[j].score:
                result.append(left[i])
                i += 1
            else:
                result.append(right[j])
                j += 1
        result.extend(left[i:])
        result.extend(right[j:])
        return result

    def _sort(lst: List[ScoredDocument]) -> List[ScoredDocument]:
        if len(lst) <= 1:
            return lst
        mid = len(lst) // 2
        left_sorted = _sort(lst[:mid])
        right_sorted = _sort(lst[mid:])
        return _merge(left_sorted, right_sorted)

    sorted_list = _sort(items)
    return sorted_list, comparisons


class Ranker:
    """Calculates relevance scores for documents and ranks them using Merge Sort."""

    def __init__(self, weight_count: float = 10.0, weight_title: float = 25.0, weight_early_pos: float = 15.0):
        self.weight_count = weight_count
        self.weight_title = weight_title
        self.weight_early_pos = weight_early_pos

    def rank_results(
        self,
        raw_matches: List[Tuple[Document, int]],
        query: str,
        doc_manager,
        match_len: int,
        max_snippets: int = 3
    ) -> Tuple[List[ScoredDocument], int]:
        """
        Aggregates raw matches by document, computes scores, and sorts via Merge Sort.
        Returns: (ranked_documents, merge_sort_comparisons)
        """
        if not raw_matches:
            return [], 0

        # Group raw matches by document ID
        doc_matches_map: Dict[int, List[int]] = {}
        doc_obj_map: Dict[int, Document] = {}

        for doc, local_pos in raw_matches:
            if doc.doc_id not in doc_matches_map:
                doc_matches_map[doc.doc_id] = []
                doc_obj_map[doc.doc_id] = doc
            doc_matches_map[doc.doc_id].append(local_pos)

        scored_docs: List[ScoredDocument] = []
        q_lower = query.lower()

        for doc_id, positions in doc_matches_map.items():
            doc = doc_obj_map[doc_id]
            positions.sort()
            count = len(positions)
            first_pos = positions[0]

            # 1. Occurrence Factor
            score_count = count * self.weight_count

            # 2. Title Match Bonus
            in_title = q_lower in doc.title.lower()
            score_title = self.weight_title if in_title else 0.0

            # 3. Early Position Bonus (logarithmic / inverted decay)
            # Earlier in the document yields higher relevance
            score_early = self.weight_early_pos * (1000.0 / (1000.0 + first_pos))

            # 4. Density Factor (matches per 1000 characters)
            density = (count / max(1, doc.char_count)) * 1000.0
            score_density = density * 2.0

            total_score = score_count + score_title + score_early + score_density

            # Generate top snippet previews
            snippets = []
            for p in positions[:max_snippets]:
                snippet = doc_manager.generate_snippet(doc.doc_id, p, match_len)
                if snippet:
                    snippets.append(snippet)

            scored_docs.append(ScoredDocument(
                document=doc,
                match_count=count,
                first_position=first_pos,
                in_title=in_title,
                score=total_score,
                snippets=snippets,
                positions=positions
            ))

        # Sort scored documents using custom Merge Sort
        ranked_docs, comparisons = merge_sort_scored_docs(scored_docs)
        return ranked_docs, comparisons
