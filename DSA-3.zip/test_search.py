"""
Unit Tests for Search Engine, Binary Search, and Inverted Index Comparison.

Test Cases:
1. "ana" in "banana"
2. Document searches for "data", "algorithm", "machine learning"
3. Standard vs LCP-accelerated binary search consistency
4. Non-matching queries
5. Prefix search ("comp")
6. Phrase search ("operating systems", "machine learning")
7. Case-insensitivity ("ALGORITHM" == "algorithm")
8. Result ranking order
9. Inverted Index search verification
"""

import os
import unittest
from backend.suffix_array import SuffixArray
from backend.lcp import LCPArray
from backend.binary_search import standard_binary_search, lcp_accelerated_binary_search
from backend.search_engine import SearchEngine


class TestSearchEngine(unittest.TestCase):
    """Verifies search algorithms, ranking, and document mapping."""

    @classmethod
    def setUpClass(cls):
        docs_dir = os.path.join(os.path.dirname(__file__), "..", "data", "documents")
        cls.engine = SearchEngine(docs_dir)

    def test_banana_ana_search(self):
        text = "banana"
        sa = SuffixArray(text).get_suffix_array()
        lcp_obj = LCPArray(text, sa)

        std_res = standard_binary_search(text, sa, "ana")
        lcp_res = lcp_accelerated_binary_search(text, sa, lcp_obj, "ana")

        # "ana" appears at index 1 ("anana") and index 3 ("ana")
        expected_positions = [1, 3]
        self.assertEqual(std_res.matches, expected_positions)
        self.assertEqual(lcp_res.matches, expected_positions)

    def test_search_consistency_std_vs_lcp(self):
        """Verifies that Standard Binary Search and LCP Binary Search return identical matches."""
        queries = ["algorithm", "data", "process", "network", "cloud", "concurrency", "tree"]
        text = self.engine.doc_manager.normalized_text
        sa = self.engine.suffix_array_obj.get_suffix_array()
        lcp_obj = self.engine.lcp_obj

        for q in queries:
            std_res = standard_binary_search(text, sa, q)
            lcp_res = lcp_accelerated_binary_search(text, sa, lcp_obj, q)
            self.assertEqual(
                std_res.matches,
                lcp_res.matches,
                f"Mismatch for query '{q}': std={std_res.matches} vs lcp={lcp_res.matches}"
            )

    def test_search_algorithm_found(self):
        res = self.engine.search("algorithm", search_type="substring", use_lcp_accel=True)
        self.assertGreater(res["total_matches"], 0)
        self.assertGreater(res["document_matches_count"], 0)
        # Document on Algorithms should rank highest or near top
        top_doc = res["results"][0]
        self.assertIn("Algorithm", top_doc["title"])

    def test_search_data_found(self):
        res = self.engine.search("data", search_type="substring", use_lcp_accel=True)
        self.assertGreater(res["total_matches"], 10)
        top_titles = [d["title"] for d in res["results"]]
        self.assertTrue(any("Data Structures" in t for t in top_titles))

    def test_phrase_search(self):
        res = self.engine.search("machine learning", search_type="phrase", use_lcp_accel=True)
        self.assertGreater(res["total_matches"], 0)
        top_doc = res["results"][0]
        self.assertIn("Machine Learning", top_doc["title"])

    def test_prefix_search(self):
        res = self.engine.search("comp", search_type="prefix", use_lcp_accel=True)
        self.assertGreater(res["total_matches"], 0)
        # Verify all mapped matches start on word boundaries
        for doc_item in res["results"]:
            for pos in doc_item["positions"]:
                doc = self.engine.doc_manager.doc_map[doc_item["doc_id"]]
                if pos > 0:
                    prev_char = doc.content[pos - 1]
                    self.assertFalse(prev_char.isalnum(), f"Prefix match at pos {pos} not on boundary: char '{prev_char}'")

    def test_nonexistent_query(self):
        res = self.engine.search("supercalifragilistic_nonexistent_query", search_type="substring")
        self.assertEqual(res["total_matches"], 0)
        self.assertEqual(res["results"], [])
        self.assertEqual(res["document_matches_count"], 0)

    def test_case_insensitivity(self):
        res_lower = self.engine.search("algorithm", search_type="substring")
        res_upper = self.engine.search("ALGORITHM", search_type="substring")
        res_mixed = self.engine.search("AlGoRiThM", search_type="substring")

        self.assertEqual(res_lower["total_matches"], res_upper["total_matches"])
        self.assertEqual(res_lower["total_matches"], res_mixed["total_matches"])

    def test_ranking_descending_order(self):
        res = self.engine.search("data", search_type="substring")
        scores = [d["score"] for d in res["results"]]
        # Scores should be in non-increasing order
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_inverted_index_consistency(self):
        inv = self.engine.inverted_index
        inv_res = inv.search_exact_word("algorithm")
        self.assertGreater(inv_res["matches_count"], 0)
        self.assertGreater(inv_res["matching_documents_count"], 0)


if __name__ == "__main__":
    unittest.main()
