"""
Root execution script for Full-Text Search Engine on a Suffix-Array Index.
"""

import sys
import unittest
from backend.app import main

if __name__ == "__main__":
    if "--test" in sys.argv:
        print("[*] Running DSA Test Suite...")
        suite = unittest.defaultTestLoader.discover("tests")
        runner = unittest.TextTestRunner(verbosity=2)
        res = runner.run(suite)
        sys.exit(0 if res.wasSuccessful() else 1)
    else:
        main()
