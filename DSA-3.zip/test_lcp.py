"""
Unit Tests for Kasai's LCP Array Algorithm and Range Minimum Query (RMQ).

Test Cases:
1. "banana" known LCP values
2. Comparison of Kasai LCP vs Naive LCP for multiple strings:
   - "banana"
   - "mississippi"
   - "abracadabra"
   - "aaaa"
   - "fulltextsearch"
3. Verification of Sparse Table RMQ against manual interval minimums.
"""

import unittest
from backend.suffix_array import build_suffix_array
from backend.lcp import LCPArray, build_lcp_array, build_lcp_naive


class TestLCPArray(unittest.TestCase):
    """Verifies correctness of Kasai's O(n) LCP algorithm and Sparse Table RMQ."""

    def test_banana_lcp(self):
        text = "banana"
        sa = build_suffix_array(text)  # [5, 3, 1, 0, 4, 2]
        lcp = build_lcp_array(text, sa)
        # Suffixes:
        # SA[0] = 5: "a"       -> LCP[0] = 0
        # SA[1] = 3: "ana"     -> LCP("a", "ana") = 1
        # SA[2] = 1: "anana"   -> LCP("ana", "anana") = 3
        # SA[3] = 0: "banana"  -> LCP("anana", "banana") = 0
        # SA[4] = 4: "na"      -> LCP("banana", "na") = 0
        # SA[5] = 2: "nana"    -> LCP("na", "nana") = 2
        expected_lcp = [0, 1, 3, 0, 0, 2]
        self.assertEqual(lcp, expected_lcp)

    def test_kasai_matches_naive_mississippi(self):
        text = "mississippi"
        sa = build_suffix_array(text)
        kasai_lcp = build_lcp_array(text, sa)
        naive_lcp = build_lcp_naive(text, sa)
        self.assertEqual(kasai_lcp, naive_lcp)

    def test_kasai_matches_naive_abracadabra(self):
        text = "abracadabra"
        sa = build_suffix_array(text)
        kasai_lcp = build_lcp_array(text, sa)
        naive_lcp = build_lcp_naive(text, sa)
        self.assertEqual(kasai_lcp, naive_lcp)

    def test_repeated_characters(self):
        text = "aaaa"
        sa = build_suffix_array(text)  # [3, 2, 1, 0]
        # "a", "aa", "aaa", "aaaa"
        kasai_lcp = build_lcp_array(text, sa)
        naive_lcp = build_lcp_naive(text, sa)
        self.assertEqual(kasai_lcp, naive_lcp)
        self.assertEqual(kasai_lcp, [0, 1, 2, 3])

    def test_sparse_table_rmq(self):
        text = "mississippi"
        sa = build_suffix_array(text)
        lcp_obj = LCPArray(text, sa)
        lcp = lcp_obj.get_lcp_array()

        # Check RMQ over all pairs (i, j)
        n = len(text)
        for i in range(n):
            for j in range(i, n):
                expected_min = min(lcp[i: j + 1])
                rmq_res = lcp_obj.query_rmq(i, j)
                self.assertEqual(rmq_res, expected_min)

    def test_suffix_lcp_sparse_table(self):
        text = "banana"
        sa = build_suffix_array(text)
        lcp_obj = LCPArray(text, sa)
        # SA: [5, 3, 1, 0, 4, 2]
        # Suffix at rank 1: "ana" (sa[1]=3)
        # Suffix at rank 2: "anana" (sa[2]=1)
        # Their LCP is 3
        self.assertEqual(lcp_obj.get_suffix_lcp(1, 2), 3)

        # Suffix at rank 0: "a" (sa[0]=5)
        # Suffix at rank 2: "anana" (sa[2]=1)
        # Their LCP is min(LCP[1], LCP[2]) = min(1, 3) = 1
        self.assertEqual(lcp_obj.get_suffix_lcp(0, 2), 1)


if __name__ == "__main__":
    unittest.main()
