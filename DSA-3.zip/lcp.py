"""
Kasai's Algorithm for Longest Common Prefix (LCP) Array and Range Minimum Query (RMQ).

Time Complexity:
- Kasai LCP Array: O(n)
- Sparse Table Construction: O(n log n)
- RMQ Query: O(1)
Space Complexity: O(n log n) for Sparse Table, O(n) for LCP.

Core DSA Concept:
LCP[i] stores the length of the longest common prefix between suffix SA[i - 1]
and suffix SA[i] in the lexicographically sorted Suffix Array.
LCP[0] is set to 0 by convention.

Kasai's insight:
If suffix i has LCP h with its predecessor in SA, then suffix i + 1 will have
an LCP of at least h - 1 with its predecessor in SA.
This eliminates redundant character comparisons and guarantees strictly O(n) time.
"""

from typing import List, Dict, Any, Tuple
import math


class LCPArray:
    """
    Computes the LCP array using Kasai's algorithm in O(n) time,
    and builds an RMQ (Range Minimum Query) Sparse Table for O(1) LCP queries.
    """

    def __init__(self, text: str, sa: List[int]):
        self.text = text
        self.n = len(text)
        self.sa = sa
        self.lcp: List[int] = []
        self.rank: List[int] = []  # Inverse suffix array
        self.history: List[Dict[str, Any]] = []  # Educational step-by-step trace
        self.sparse_table: List[List[int]] = []

        if self.n > 0 and len(sa) == self.n:
            self.lcp = self._build_kasai()
            self._build_sparse_table()
        elif self.n > 0:
            self.lcp = [0] * self.n

    def _build_kasai(self) -> List[int]:
        """
        Kasai's Algorithm for computing LCP in O(n) time.
        """
        n = self.n
        sa = self.sa
        lcp = [0] * n

        # rank[i] is the position of suffix text[i:] in the sorted Suffix Array
        self.rank = [0] * n
        for r in range(n):
            self.rank[sa[r]] = r

        h = 0  # current LCP length
        for i in range(n):
            r = self.rank[i]
            if r > 0:
                j = sa[r - 1]  # The suffix immediately preceding suffix i in SA

                # Compare characters starting from index h
                chars_compared = 0
                while (i + h < n) and (j + h < n) and (self.text[i + h] == self.text[j + h]):
                    h += 1
                    chars_compared += 1

                lcp[r] = h

                # Record educational step for visualization
                if n <= 100:  # Avoid excessive memory for huge texts
                    self.history.append({
                        "original_index_i": i,
                        "suffix_i": self.text[i:min(n, i + 15)],
                        "sa_rank_r": r,
                        "predecessor_suffix_j": self.text[j:min(n, j + 15)],
                        "matched_lcp_h": h,
                        "common_prefix": self.text[i:i + h]
                    })

                # For suffix i + 1, LCP with its predecessor will be at least h - 1
                if h > 0:
                    h -= 1
            else:
                lcp[0] = 0
                h = 0

        return lcp

    def _build_sparse_table(self):
        """
        Constructs a Sparse Table over the LCP array to support Range Minimum Query (RMQ)
        in O(1) time.
        
        The LCP between any two arbitrary suffixes SA[i] and SA[j] (i < j)
        is equal to min(LCP[i + 1], LCP[i + 2], ..., LCP[j]).
        """
        n = self.n
        if n == 0:
            return

        # Number of levels in sparse table: floor(log2(n)) + 1
        log_n = int(math.floor(math.log2(n))) + 1 if n > 0 else 1
        self.sparse_table = [[0] * n for _ in range(log_n)]

        # Base level: length 2^0 = 1
        for i in range(n):
            self.sparse_table[0][i] = self.lcp[i]

        # Dynamic programming for levels: st[k][i] = min(st[k-1][i], st[k-1][i + 2^(k-1)])
        k = 1
        while (1 << k) <= n:
            length = 1 << (k - 1)
            for i in range(n - (1 << k) + 1):
                self.sparse_table[k][i] = min(
                    self.sparse_table[k - 1][i],
                    self.sparse_table[k - 1][i + length]
                )
            k += 1

    def query_rmq(self, left: int, right: int) -> int:
        """
        Range Minimum Query: returns min(LCP[left ... right]) in O(1) time.
        """
        if left > right or left < 0 or right >= self.n:
            return 0
        if left == right:
            return self.lcp[left]

        k = int(math.floor(math.log2(right - left + 1)))
        return min(
            self.sparse_table[k][left],
            self.sparse_table[k][right - (1 << k) + 1]
        )

    def get_suffix_lcp(self, i: int, j: int) -> int:
        """
        Computes the LCP between suffix SA[i] and suffix SA[j] in O(1) using the Sparse Table.
        Requires i != j. If i == j, returns remaining length of suffix.
        """
        if i == j:
            return self.n - self.sa[i]
        if i > j:
            i, j = j, i
        # The LCP between SA[i] and SA[j] is min(LCP[i+1 ... j])
        return self.query_rmq(i + 1, j)

    def get_lcp_array(self) -> List[int]:
        """Returns the computed LCP array."""
        return self.lcp

    def get_visualization_data(self) -> Dict[str, Any]:
        """Returns formatted LCP data for visualization."""
        items = []
        for r in range(self.n):
            suffix_idx = self.sa[r]
            items.append({
                "rank": r,
                "suffix_idx": suffix_idx,
                "suffix": self.text[suffix_idx:],
                "lcp": self.lcp[r],
                "common_prefix_with_prev": self.text[suffix_idx: suffix_idx + self.lcp[r]] if r > 0 else ""
            })
        return {
            "lcp_array": self.lcp,
            "items": items,
            "trace": self.history
        }


def build_lcp_array(text: str, sa: List[int]) -> List[int]:
    """Helper function to build LCP array."""
    return LCPArray(text, sa).get_lcp_array()


def build_lcp_naive(text: str, sa: List[int]) -> List[int]:
    """
    Naive LCP computation by comparing characters one by one.
    Used for unit testing and verifying Kasai's algorithm.
    """
    n = len(text)
    if n == 0:
        return []
    lcp = [0] * n
    for r in range(1, n):
        s1 = text[sa[r - 1]:]
        s2 = text[sa[r]:]
        common = 0
        while common < len(s1) and common < len(s2) and s1[common] == s2[common]:
            common += 1
        lcp[r] = common
    return lcp
