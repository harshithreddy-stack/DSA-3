# Full-Text Search Engine on a Suffix-Array Index
## Data Structures and Algorithms (DSA) Course Project

A full-text search engine implemented from scratch in Python to demonstrate advanced string data structures and algorithms on a multi-document text corpus.

The search engine constructs a Suffix Array over the combined text corpus, computes the Longest Common Prefix (LCP) array using Kasai's algorithm, and uses LCP-accelerated binary search to locate substring, prefix, and phrase queries without scanning the text.

---

## 1. Problem Statement & Motivation

Traditional string search across documents often relies on linear text scanning ($\mathcal{O}(n)$ per query), which becomes impractical as the collection grows. While standard Inverted Indexes are common in commercial search engines, they operate on discrete word tokens and cannot efficiently handle arbitrary intra-word substrings (e.g. searching for `"gorith"` inside `"algorithm"`) without large $n$-gram indexes or full vocabulary scans.

By constructing a **Suffix Array** and an **LCP Array**, any arbitrary pattern of length $m$ can be located in $\mathcal{O}(m + \log n)$ time regardless of whether it is a full word, a word prefix, an intra-word substring, or a multi-word phrase.

---

## 2. Core DSA Components Implemented from Scratch

All data structures and algorithms in this project are implemented manually without external search libraries:

1. **Suffix Array (`backend/suffix_array.py`)**
   - Constructed using the Manber-Myers **Prefix Doubling / Ranking** approach.
   - Time Complexity: $\mathcal{O}(n \log^2 n)$.
   - Space Complexity: $\mathcal{O}(n)$.

2. **Kasai's LCP Array (`backend/lcp.py`)**
   - Computes the Longest Common Prefix (LCP) between adjacent suffixes in the sorted Suffix Array.
   - Time Complexity: $\mathcal{O}(n)$ amortized linear time.
   - Space Complexity: $\mathcal{O}(n)$.

3. **Sparse Table Range Minimum Query (RMQ) (`backend/lcp.py`)**
   - Precomputes interval minimums over the LCP array in $\mathcal{O}(n \log n)$ time.
   - Allows $\mathcal{O}(1)$ LCP queries between any two arbitrary suffixes in the array.

4. **LCP-Accelerated Binary Search (`backend/binary_search.py`)**
   - Implements the Manber-Myers accelerated binary search.
   - Uses precomputed LCP values from the Sparse Table to skip characters already known to match.
   - Reduces character comparisons from $\mathcal{O}(m \log n)$ to $\mathcal{O}(m + \log n)$.

5. **Document Boundary Mapping (`backend/document_manager.py`)**
   - Concatenates 10 text documents using delimiter sentinels (`\x00`).
   - Uses binary search over document boundary ranges in $\mathcal{O}(\log D)$ time to map global suffix positions back to local document offsets and titles.

6. **Relevance Ranking & Custom MergeSort (`backend/ranking.py`)**
   - Scores documents based on match frequency, title matches, match density, and position prominence.
   - Sorts matching documents in descending order of relevance using a custom **MergeSort** ($\mathcal{O}(K \log K)$).

7. **Baseline Inverted Index (`backend/inverted_index.py`)**
   - Tokenizes text and maintains word postings lists for comparison.
   - Used in the benchmark to demonstrate empirical tradeoffs between Suffix Arrays and Inverted Indexes.

---

## 3. Algorithm Details

### Suffix Array: Prefix Doubling
Given a text $S$ of length $n$:
1. **Base Case ($k = 0$):** Suffixes are ranked by their initial character (ASCII value).
2. **Doubling Step ($k = 1, 2, 4, 8, \dots < n$):** Suffix $i$ is represented as a 2-tuple:
   $$(\text{rank}[i], \text{rank}[i + k] \text{ if } i + k < n \text{ else } -1)$$
3. Suffixes are sorted by their 2-tuples in $\mathcal{O}(n \log n)$ time.
4. New ranks are assigned based on the sorted order. If all $n$ ranks are distinct, sorting terminates early.
5. Total rounds $\le \lceil \log_2 n \rceil$, giving overall time $\mathcal{O}(n \log^2 n)$.

### Kasai's LCP Algorithm
Kasai computes the LCP array in $\mathcal{O}(n)$ time by processing suffixes in **original text order** ($i = 0, 1, 2, \dots, n-1$):
- Suffix $i$ is located at rank $r = \text{rank}[i]$ in $SA$.
- Its predecessor in $SA$ is $j = SA[r - 1]$.
- If suffix $i$ and $j$ share $h$ characters, then suffix $i + 1$ shares at least $h - 1$ characters with its predecessor in $SA$.
- Comparisons for suffix $i + 1$ resume from offset $h - 1$.
- Because $h \le n$ and $h$ decreases at most $n$ times across the loop, $h$ can increase at most $2n$ times. The algorithm is strictly $\mathcal{O}(n)$.

### LCP Acceleration in Binary Search
When searching for pattern $P$ of length $m$:
- Maintain search bounds $[Low, High]$ with $l = \text{LCP}(P, SA[Low])$ and $r = \text{LCP}(P, SA[High])$.
- At midpoint $Mid$, query $lcp\_lm = \text{LCP}(SA[Low], SA[Mid])$ via the Sparse Table in $\mathcal{O}(1)$:
  - **If $lcp\_lm > l$:** Suffix $Mid$ matches $Low$ longer than $P$ does. $Mid$ has the same relationship to $P$ as $Low$. Set $Low = Mid$ without character comparisons.
  - **If $lcp\_lm < l$:** Suffix $Mid$ diverges from $Low$ earlier than $P$. $Mid$ is strictly greater than $P$. Set $High = Mid$ without character comparisons.
  - **If $lcp\_lm == l$:** $P$ and $Mid$ match for at least $l$ characters. Resume character comparisons directly at index $l$.

---

## 4. Textbook Trace Example: `"banana"`

For string `"banana"` ($n = 6$):

| Rank $r$ | Suffix Index $SA[r]$ | $LCP[r]$ | Common Prefix with Predecessor | Suffix Text |
| :---: | :---: | :---: | :---: | :--- |
| **0** | 5 | 0 | - | `a` |
| **1** | 3 | 1 | `a` | `ana` |
| **2** | 1 | 3 | `ana` | `anana` |
| **3** | 0 | 0 | - | `banana` |
| **4** | 4 | 0 | - | `na` |
| **5** | 2 | 2 | `na` | `nana` |

- **Suffix Array:** `[5, 3, 1, 0, 4, 2]`
- **Kasai LCP Array:** `[0, 1, 3, 0, 0, 2]`
- Querying `"ana"` finds matching suffixes at indices $SA[1] = 3$ and $SA[2] = 1$.

---

## 5. Experimental Results & Performance

Measured on the 10 indexed documents (**19,255 characters**, **19,255 suffixes**):

### 1. Index Construction Time & Size
| Metric | Suffix Array Index | Inverted Index |
| :--- | :--- | :--- |
| **Construction Time** | 166.12 ms (SA: 132.48 ms, Kasai LCP: 33.61 ms) | 2.48 ms |
| **Index Size** | ~350 KB | ~195 KB |
| **Indexed Units** | 19,255 suffixes | 2,420 words (3,124 tokens) |

### 2. Character Comparisons Saved by LCP Acceleration
| Query | Standard BS Comparisons | LCP-Accelerated Comparisons | Comparisons Saved | Reduction |
| :--- | :---: | :---: | :---: | :---: |
| `"data structures"` | 129 | **54** | **75** | **58.1%** |
| `"concurrency"` | 123 | **60** | **63** | **51.2%** |
| `"dynamic programming"` | 136 | **74** | **62** | **45.6%** |
| `"artificial intelligence"` | 161 | **88** | **73** | **45.3%** |
| `"machine learning"` | 132 | **76** | **56** | **42.4%** |
| `"algorithm"` | 97 | **66** | **31** | **32.0%** |

### 3. Suffix Array vs. Inverted Index by Query Type
| Query Type | Query | Suffix Array Latency | Inverted Index Latency | Structural Tradeoff |
| :--- | :--- | :---: | :---: | :--- |
| **Substring (Intra-word)** | `"gorith"` | **0.105 ms** | 0.812 ms | Suffix Array searches natively; Inverted Index scans entire vocabulary. |
| **Exact Word** | `"algorithm"` | **0.143 ms** | 0.015 ms | Inverted Index uses $\mathcal{O}(1)$ hash table lookup. |
| **Prefix** | `"comp"` | **0.119 ms** | 0.420 ms | Suffix Array bounds interval directly; Inverted Index scans lexicon. |
| **Phrase** | `"machine learning"` | **0.075 ms** | 0.110 ms | Suffix Array searches continuous string; Inverted Index intersects positions. |

---

## 6. Project Structure

```text
DSA/
├── backend/
│   ├── app.py                 # Flask REST application
│   ├── suffix_array.py        # Prefix Doubling Suffix Array O(n log² n)
│   ├── lcp.py                 # Kasai LCP O(n) & Sparse Table RMQ
│   ├── binary_search.py       # Standard and LCP-Accelerated Binary Search
│   ├── search_engine.py       # Engine coordinator
│   ├── document_manager.py    # Document loader & boundary mapping O(log D)
│   ├── ranking.py             # Relevance scoring & custom MergeSort
│   ├── inverted_index.py      # Baseline Inverted Index
│   └── benchmark.py           # Automated benchmark runner
│
├── data/
│   └── documents/             # 10 Computer Science text documents
│
├── frontend/
│   ├── index.html             # Clean academic dashboard & visualizer
│   ├── style.css              # Academic styling (light & dark mode support)
│   └── script.js              # Frontend UI controller
│
├── tests/
│   ├── test_suffix_array.py   # Unit tests for Suffix Array
│   ├── test_lcp.py            # Unit tests for Kasai LCP and RMQ
│   └── test_search.py         # Unit tests for search and ranking
│
├── README.md                  # Project report & documentation
├── VIVA.md                    # 35 academic viva questions and answers
├── requirements.txt           # Minimal dependencies (flask, tabulate)
├── run.bat                    # One-click Windows launch
└── run.py                     # Python runner
```

---

## 7. How to Run

### Requirements
- Python 3.10+ installed and available in PATH.

### Quick Start (Windows)
Double-click `run.bat` or run:
```cmd
run.bat
```

### Manual Execution (Any Platform)
```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run unit tests (23 tests)
python -m unittest discover tests

# 3. Run benchmark suite
python -m backend.benchmark

# 4. Start web application
python run.py
```
Open your browser at **`http://127.0.0.1:5000`**.

---

## 8. Automated Unit Tests

The test suite covers edge cases and algorithm verification:
- **Suffix Array Tests:** `"banana"`, `"mississippi"`, `"abracadabra"`, `"aaaa"`, single-character strings, empty strings, and verification against a naive $\mathcal{O}(n^2 \log n)$ construction.
- **Kasai LCP Tests:** Known ground-truth LCP arrays, verification against naive character comparisons, and Range Minimum Query (RMQ) correctness across all interval pairs.
- **Search Tests:** Substring, prefix, phrase queries, case-insensitivity, score ranking descending order, and standard vs. LCP-accelerated equivalence.

To run:
```bash
python -m unittest discover tests -v
```

---

## 9. Viva Voce Reference

Refer to [VIVA.md](VIVA.md) for 35 detailed viva questions and answers covering Suffix Arrays, Kasai's algorithm, binary search acceleration, complexity proofs, document mapping, and Inverted Index comparisons.
