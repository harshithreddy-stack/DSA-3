"""
Suffix Array Implementation using Prefix Doubling (Manber-Myers Algorithm).

Time Complexity: O(n log^2 n)
Space Complexity: O(n)

Core DSA Concept:
A Suffix Array is a sorted array of all suffixes of a string.
Given a text S of length n, suffix i is the substring S[i : n].
Instead of comparing full strings of length up to n (which takes O(n^2 log n) naively),
the prefix doubling technique sorts suffixes by examining prefixes of length 2^k
(1, 2, 4, 8, ...) using rank pairs from the previous step.
"""

from typing import List, Tuple, Dict, Any


class SuffixArray:
    """
    Suffix Array constructed using the O(n log^2 n) Prefix Doubling / Ranking approach.
    """

    def __init__(self, text: str):
        self.text = text
        self.n = len(text)
        self.sa: List[int] = []
        self.history: List[Dict[str, Any]] = []  # For DSA educational visualization
        if self.n > 0:
            self.sa = self._build_prefix_doubling()
        else:
            self.sa = []

    def _build_prefix_doubling(self) -> List[int]:
        """
        Constructs the suffix array using the prefix doubling / ranking method.
        
        Algorithm Steps:
        1. Initialize ranks based on ASCII value (or character order) of first character (k=0, length 1).
        2. In each iteration k = 1, 2, 4, 8, ... < n:
           Each suffix i is represented as a tuple: (rank[i], rank[i + k] if i + k < n else -1).
        3. Sort suffix indices based on these 2-tuples.
        4. Reassign ranks: suffixes with identical tuples get the same rank; distinct tuples get incremented ranks.
        5. Early termination: If all ranks become distinct (0 to n - 1), suffixes are completely sorted.
        6. Total iterations <= ceil(log2(n)). Each iteration sorts n pairs in O(n log n). Total: O(n log^2 n).
        """
        n = self.n
        if n == 0:
            return []
        if n == 1:
            self.history.append({
                "k": 0,
                "length": 1,
                "table": [{"index": 0, "suffix": self.text, "rank_pair": [ord(self.text[0]), -1], "new_rank": 0}]
            })
            return [0]

        # Step 1: Base ranking by first character
        # rank[i] holds the current rank of suffix starting at i
        rank = [ord(self.text[i]) for i in range(n)]
        sa = list(range(n))

        k = 1
        step_idx = 1
        while k < n:
            # Step 2: Build rank pairs for each suffix i: (rank[i], rank[i + k] if i + k < n else -1)
            # We sort indices based on their tuple (primary_rank, secondary_rank)
            def get_key(i: int) -> Tuple[int, int]:
                sec = rank[i + k] if (i + k < n) else -1
                return (rank[i], sec)

            # Sort suffix indices using standard comparison on 2-tuples: O(n log n)
            # Custom merge sort or timsort both achieve O(n log n) for pairs of integers
            sa.sort(key=get_key)

            # Step 3: Reassign ranks
            temp_rank = [0] * n
            temp_rank[sa[0]] = 0
            cur_rank = 0

            step_table = []
            prev_key = get_key(sa[0])
            step_table.append({
                "sa_pos": 0,
                "suffix_idx": sa[0],
                "suffix_str": self.text[sa[0]:min(n, sa[0] + 2 * k)],
                "rank_pair": list(prev_key),
                "assigned_rank": 0
            })

            for i in range(1, n):
                cur_key = get_key(sa[i])
                if cur_key != prev_key:
                    cur_rank += 1
                    prev_key = cur_key
                temp_rank[sa[i]] = cur_rank

                step_table.append({
                    "sa_pos": i,
                    "suffix_idx": sa[i],
                    "suffix_str": self.text[sa[i]:min(n, sa[i] + 2 * k)],
                    "rank_pair": list(cur_key),
                    "assigned_rank": cur_rank
                })

            self.history.append({
                "step": step_idx,
                "k": k,
                "compared_length": 2 * k,
                "table": step_table
            })

            rank = temp_rank
            step_idx += 1

            # Early break: if all ranks are unique, the suffixes are already in final sorted order
            if cur_rank == n - 1:
                break

            k *= 2

        return sa

    def get_suffix_array(self) -> List[int]:
        """Returns the computed Suffix Array."""
        return self.sa

    def get_suffixes(self) -> List[str]:
        """Returns all original suffixes in their natural index order (0 to n - 1)."""
        return [self.text[i:] for i in range(self.n)]

    def get_sorted_suffixes(self) -> List[Tuple[int, str]]:
        """Returns sorted suffixes with their original starting index: [(index, suffix_text), ...]."""
        return [(i, self.text[i:]) for i in self.sa]

    def get_visualization_data(self) -> Dict[str, Any]:
        """Returns structured data suitable for rendering the DSA visualization."""
        return {
            "text": self.text,
            "length": self.n,
            "original_suffixes": [{"index": i, "suffix": self.text[i:]} for i in range(self.n)],
            "suffix_array": self.sa,
            "sorted_suffixes": [
                {
                    "rank": r,
                    "suffix_index": self.sa[r],
                    "suffix": self.text[self.sa[r]:]
                }
                for r in range(self.n)
            ],
            "history": self.history
        }


def build_suffix_array(text: str) -> List[int]:
    """Helper function to build suffix array."""
    return SuffixArray(text).get_suffix_array()


def build_suffix_array_naive(text: str) -> List[int]:
    """
    Naive Suffix Array construction in O(n^2 log n).
    Used for unit testing and verifying the doubling algorithm.
    """
    n = len(text)
    suffixes = [(text[i:], i) for i in range(n)]
    suffixes.sort(key=lambda x: x[0])
    return [item[1] for item in suffixes]
