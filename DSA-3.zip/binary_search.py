"""
Binary Search and LCP-Accelerated Binary Search over Suffix Array.

Time Complexities:
- Standard Binary Search: O(m * log n)
- LCP-Accelerated Binary Search: O(m + log n)
where n = len(text), m = len(pattern).

Core DSA Concept:
Since suffixes are lexicographically sorted in the Suffix Array,
all occurrences of a pattern P appear as prefixes of a contiguous range
of suffixes [L, R] in the Suffix Array.

LCP Acceleration:
By leveraging precomputed LCP values (via Range Minimum Query over the Kasai LCP array),
we can skip already-matched characters during binary search probes, reducing
character comparisons from O(m * log n) to O(m + log n).
"""

from typing import List, Tuple, Dict, Any, Optional
from .lcp import LCPArray


class SearchResult:
    """Encapsulates the range and metrics of a suffix array pattern search."""

    def __init__(self, left: int, right: int, matches: List[int], comparisons: int, trace: List[Dict[str, Any]]):
        self.left = left            # Left index in Suffix Array (-1 if none)
        self.right = right          # Right index in Suffix Array (-1 if none)
        self.matches = matches      # List of starting positions in original text
        self.comparisons = comparisons  # Number of character comparisons performed
        self.trace = trace          # Step-by-step trace for visualization/debugging

    def to_dict(self) -> Dict[str, Any]:
        return {
            "left": self.left,
            "right": self.right,
            "match_count": len(self.matches),
            "match_positions": self.matches,
            "comparisons": self.comparisons,
            "trace": self.trace
        }


def standard_binary_search(text: str, sa: List[int], pattern: str) -> SearchResult:
    """
    Standard Binary Search over Suffix Array without LCP acceleration.
    Complexity: O(m * log n) character comparisons.
    """
    n = len(text)
    m = len(pattern)
    if n == 0 or m == 0 or len(sa) != n:
        return SearchResult(-1, -1, [], 0, [])

    trace = []
    comparisons = 0

    # Step 1: Find Lower Bound (first suffix that is >= pattern)
    low = 0
    high = n - 1
    lower_bound = n

    while low <= high:
        mid = (low + high) // 2
        suffix_pos = sa[mid]
        suffix = text[suffix_pos: min(n, suffix_pos + m)]

        # Compare character by character up to m
        match_len = 0
        while match_len < m and match_len < (n - suffix_pos):
            comparisons += 1
            if pattern[match_len] != text[suffix_pos + match_len]:
                break
            match_len += 1

        is_suffix_ge = False
        if match_len == m:
            is_suffix_ge = True
        elif match_len == (n - suffix_pos):
            # Suffix ran out of characters before pattern, so suffix < pattern
            is_suffix_ge = False
        else:
            is_suffix_ge = (text[suffix_pos + match_len] >= pattern[match_len])

        trace.append({
            "phase": "lower_bound",
            "low": low,
            "high": high,
            "mid": mid,
            "suffix_pos": suffix_pos,
            "suffix_prefix": suffix,
            "match_len": match_len,
            "action": "go_left" if is_suffix_ge else "go_right"
        })

        if is_suffix_ge:
            lower_bound = mid
            high = mid - 1
        else:
            low = mid + 1

    # Check if pattern matches at lower_bound
    if lower_bound >= n or not text[sa[lower_bound]:].startswith(pattern):
        return SearchResult(-1, -1, [], comparisons, trace)

    # Step 2: Find Upper Bound (last suffix that starts with pattern)
    low = lower_bound
    high = n - 1
    upper_bound = lower_bound

    while low <= high:
        mid = (low + high) // 2
        suffix_pos = sa[mid]
        suffix = text[suffix_pos: min(n, suffix_pos + m)]

        match_len = 0
        while match_len < m and match_len < (n - suffix_pos):
            comparisons += 1
            if pattern[match_len] != text[suffix_pos + match_len]:
                break
            match_len += 1

        is_suffix_le = False
        if match_len == m:
            # Starts with pattern
            is_suffix_le = True
        elif match_len == (n - suffix_pos):
            is_suffix_le = True
        else:
            is_suffix_le = (text[suffix_pos + match_len] <= pattern[match_len])

        trace.append({
            "phase": "upper_bound",
            "low": low,
            "high": high,
            "mid": mid,
            "suffix_pos": suffix_pos,
            "suffix_prefix": suffix,
            "match_len": match_len,
            "action": "go_right" if is_suffix_le else "go_left"
        })

        if is_suffix_le:
            if text[suffix_pos:].startswith(pattern):
                upper_bound = max(upper_bound, mid)
            low = mid + 1
        else:
            high = mid - 1

    matches = [sa[i] for i in range(lower_bound, upper_bound + 1)]
    matches.sort()  # Sort starting positions in text order
    return SearchResult(lower_bound, upper_bound, matches, comparisons, trace)


def _compute_lcp_strings(s1: str, s2: str, start_k: int = 0) -> Tuple[int, int]:
    """
    Computes LCP between two strings starting comparison from index start_k.
    Returns (lcp_len, comparison_count).
    """
    k = start_k
    comps = 0
    max_len = min(len(s1), len(s2))
    while k < max_len:
        comps += 1
        if s1[k] != s2[k]:
            break
        k += 1
    return k, comps


def lcp_accelerated_binary_search(
    text: str,
    sa: List[int],
    lcp_obj: LCPArray,
    pattern: str
) -> SearchResult:
    """
    Textbook Manber-Myers LCP-Accelerated Binary Search over Suffix Array.
    Complexity: O(m + log n) character comparisons.
    
    Uses Range Minimum Queries (RMQ) from the Kasai LCP array to determine
    the LCP between Suffix Array positions in O(1) time, skipping redundant
    character comparisons.
    """
    n = len(text)
    m = len(pattern)
    if n == 0 or m == 0 or len(sa) != n:
        return SearchResult(-1, -1, [], 0, [])

    trace = []
    comparisons = 0

    def find_bound_manber_myers(find_lower: bool) -> int:
        nonlocal comparisons
        
        # Initial boundary comparisons
        l_lcp, c_l = _compute_lcp_strings(pattern, text[sa[0]:], 0)
        r_lcp, c_r = _compute_lcp_strings(pattern, text[sa[n - 1]:], 0)
        comparisons += c_l + c_r

        # Boundary checks
        if find_lower:
            if l_lcp == m or (l_lcp < len(text[sa[0]:]) and text[sa[0] + l_lcp] >= pattern[l_lcp]):
                return 0
            if r_lcp < m and (r_lcp >= len(text[sa[n - 1]:]) or text[sa[n - 1] + r_lcp] < pattern[r_lcp]):
                return -1  # Pattern strictly greater than all suffixes
        else:
            if text[sa[n - 1]:].startswith(pattern):
                return n - 1
            if not text[sa[0]:].startswith(pattern) and pattern < text[sa[0]:]:
                return -1

        low = 0
        high = n - 1
        cur_l = l_lcp
        cur_r = r_lcp

        while high - low > 1:
            mid = (low + high) // 2
            # Query RMQ for LCP between SA[low] and SA[mid]
            lcp_lm = lcp_obj.get_suffix_lcp(low, mid)

            if lcp_lm > cur_l:
                # Case 1: lcp_lm > cur_l
                # Suffix mid shares more with suffix low than pattern does.
                # Mid compares to pattern identically to low.
                low = mid
                trace.append({
                    "low": low, "high": high, "mid": mid,
                    "case": 1, "lcp_lm": lcp_lm, "cur_l": cur_l,
                    "action": "low=mid", "skipped_chars": cur_l, "comps": 0
                })
            elif lcp_lm < cur_l:
                # Case 2: lcp_lm < cur_l
                # Suffix mid diverges from suffix low earlier than pattern.
                # Mid must be strictly greater than pattern.
                high = mid
                cur_r = lcp_lm
                trace.append({
                    "low": low, "high": high, "mid": mid,
                    "case": 2, "lcp_lm": lcp_lm, "cur_l": cur_l,
                    "action": "high=mid", "skipped_chars": lcp_lm, "comps": 0
                })
            else:
                # Case 3: lcp_lm == cur_l
                # Suffix mid and pattern share at least cur_l characters!
                # Skip first cur_l characters and resume comparisons from cur_l!
                k, comps = _compute_lcp_strings(pattern, text[sa[mid]:], cur_l)
                comparisons += comps

                mid_suffix = text[sa[mid]:]
                if k == m:
                    # Suffix mid starts with pattern
                    if find_lower:
                        high = mid
                        cur_r = k
                    else:
                        low = mid
                        cur_l = k
                elif k < len(mid_suffix) and pattern[k:] < mid_suffix[k:]:
                    high = mid
                    cur_r = k
                else:
                    low = mid
                    cur_l = k

                trace.append({
                    "low": low, "high": high, "mid": mid,
                    "case": 3, "lcp_lm": lcp_lm, "cur_l": cur_l,
                    "matched_k": k, "skipped_chars": cur_l, "comps": comps,
                    "action": "offset_compare"
                })

        # Final evaluation between low and high
        if find_lower:
            if text[sa[low]:].startswith(pattern):
                return low
            if text[sa[high]:].startswith(pattern):
                return high
            return -1
        else:
            if text[sa[high]:].startswith(pattern):
                return high
            if text[sa[low]:].startswith(pattern):
                return low
            return -1

    # Find lower bound
    lower_bound = find_bound_manber_myers(find_lower=True)
    if lower_bound == -1:
        return SearchResult(-1, -1, [], comparisons, trace)

    # Find upper bound
    upper_bound = find_bound_manber_myers(find_lower=False)
    if upper_bound == -1 or upper_bound < lower_bound:
        upper_bound = lower_bound

    matches = [sa[i] for i in range(lower_bound, upper_bound + 1)]
    matches.sort()
    return SearchResult(lower_bound, upper_bound, matches, comparisons, trace)
