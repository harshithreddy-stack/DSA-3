"""
Inverted Index Implementation from Scratch for DSA Comparison.

Time Complexities:
- Exact Word Search: O(1) dictionary lookup + O(P) postings retrieval.
- Phrase Search: O(P1 + P2) positional intersection of postings lists.
- Prefix Search: O(V * L) linear lexicon scan or O(L * log V) with sorted lexicon.
- Arbitrary Substring Search: O(V * L) full lexicon scan (Inverted Index limitation).

Space Complexity:
- Lexicon + Postings Lists: O(Total Words) with overhead for document/position tuples.

Core DSA Comparison:
Inverted Index vs Suffix Array:
1. Inverted Index indexes discrete words/tokens. Excellent for word/phrase search,
   poor for arbitrary intra-word substring search without n-gram expansion.
2. Suffix Array indexes all character suffixes. Supports arbitrary substring search,
   prefix search, and phrase search with uniform O(m log n) or O(m + log n) complexity.
"""

import time
import re
import sys
from typing import List, Dict, Any, Tuple, Set, Optional
from .document_manager import Document


class InvertedIndex:
    """
    Inverted Index storing postings: term -> { doc_id: [word_positions] }.
    """

    def __init__(self):
        # Postings structure: term -> { doc_id: [word_offset_0, word_offset_1, ...] }
        self.index: Dict[str, Dict[int, List[int]]] = {}
        self.doc_lengths: Dict[int, int] = {}
        self.total_tokens: int = 0
        self.build_time_ms: float = 0.0

    def _tokenize(self, text: str) -> List[Tuple[str, int]]:
        """
        Tokenizes text into words and tracks word index.
        Returns list of (token, word_index).
        """
        # Split on non-alphanumeric characters, keeping tokens lowercase
        tokens = []
        raw_words = re.findall(r"\b\w+\b", text.lower())
        for idx, word in enumerate(raw_words):
            tokens.append((word, idx))
        return tokens

    def build(self, documents: List[Document]):
        """Builds the inverted index from a list of Document objects."""
        start_t = time.perf_counter()
        self.index = {}
        self.doc_lengths = {}
        self.total_tokens = 0

        for doc in documents:
            tokens = self._tokenize(doc.content)
            self.doc_lengths[doc.doc_id] = len(tokens)
            self.total_tokens += len(tokens)

            for token, word_idx in tokens:
                if token not in self.index:
                    self.index[token] = {}
                if doc.doc_id not in self.index[token]:
                    self.index[token][doc.doc_id] = []
                self.index[token][doc.doc_id].append(word_idx)

        end_t = time.perf_counter()
        self.build_time_ms = round((end_t - start_t) * 1000.0, 3)

    def search_exact_word(self, word: str) -> Dict[str, Any]:
        """Looks up an exact word in O(1) hash lookup."""
        start_t = time.perf_counter()
        w = word.lower().strip()
        postings = self.index.get(w, {})
        doc_matches = {doc_id: len(pos_list) for doc_id, pos_list in postings.items()}
        total_matches = sum(doc_matches.values())
        elapsed_ms = (time.perf_counter() - start_t) * 1000.0

        return {
            "query": word,
            "query_type": "exact_word",
            "matches_count": total_matches,
            "matching_documents_count": len(doc_matches),
            "doc_matches": doc_matches,
            "latency_ms": round(elapsed_ms, 4)
        }

    def search_prefix(self, prefix: str) -> Dict[str, Any]:
        """
        Searches words starting with prefix by scanning the vocabulary.
        Complexity: O(V) where V is the vocabulary size.
        """
        start_t = time.perf_counter()
        pref = prefix.lower().strip()
        doc_matches: Dict[int, int] = {}
        matching_words: List[str] = []

        for word, postings in self.index.items():
            if word.startswith(pref):
                matching_words.append(word)
                for doc_id, positions in postings.items():
                    doc_matches[doc_id] = doc_matches.get(doc_id, 0) + len(positions)

        elapsed_ms = (time.perf_counter() - start_t) * 1000.0
        return {
            "query": prefix,
            "query_type": "prefix",
            "matching_words": matching_words[:10],
            "matches_count": sum(doc_matches.values()),
            "matching_documents_count": len(doc_matches),
            "doc_matches": doc_matches,
            "latency_ms": round(elapsed_ms, 4)
        }

    def search_substring(self, substring: str) -> Dict[str, Any]:
        """
        Searches for arbitrary substring across all tokens in vocabulary.
        Limitation of Inverted Index: Requires O(V * L) linear scan of all vocabulary words.
        Cannot match arbitrary text across word boundaries or inside non-indexed delimiters.
        """
        start_t = time.perf_counter()
        sub = substring.lower().strip()
        doc_matches: Dict[int, int] = {}
        matching_words: List[str] = []

        for word, postings in self.index.items():
            if sub in word:
                matching_words.append(word)
                for doc_id, positions in postings.items():
                    doc_matches[doc_id] = doc_matches.get(doc_id, 0) + len(positions)

        elapsed_ms = (time.perf_counter() - start_t) * 1000.0
        return {
            "query": substring,
            "query_type": "substring",
            "matching_words": matching_words[:10],
            "matches_count": sum(doc_matches.values()),
            "matching_documents_count": len(doc_matches),
            "doc_matches": doc_matches,
            "latency_ms": round(elapsed_ms, 4)
        }

    def search_phrase(self, phrase: str) -> Dict[str, Any]:
        """
        Positional phrase search: checks that words appear consecutively:
        word_pos[i + 1] == word_pos[i] + 1 in the same document.
        Complexity: O(sum of postings lengths).
        """
        start_t = time.perf_counter()
        tokens = [t[0] for t in self._tokenize(phrase)]
        if not tokens:
            return {"query": phrase, "matches_count": 0, "matching_documents_count": 0, "latency_ms": 0.0}

        # If any token is absent, phrase cannot exist
        for t in tokens:
            if t not in self.index:
                elapsed_ms = (time.perf_counter() - start_t) * 1000.0
                return {
                    "query": phrase,
                    "query_type": "phrase",
                    "matches_count": 0,
                    "matching_documents_count": 0,
                    "doc_matches": {},
                    "latency_ms": round(elapsed_ms, 4)
                }

        # Candidate documents must contain all tokens
        candidate_docs = set(self.index[tokens[0]].keys())
        for t in tokens[1:]:
            candidate_docs &= set(self.index[t].keys())

        doc_matches: Dict[int, int] = {}

        for doc_id in candidate_docs:
            first_positions = self.index[tokens[0]][doc_id]
            phrase_occurrences = 0

            for pos in first_positions:
                match = True
                for offset, next_token in enumerate(tokens[1:], start=1):
                    expected_pos = pos + offset
                    if expected_pos not in self.index[next_token][doc_id]:
                        match = False
                        break
                if match:
                    phrase_occurrences += 1

            if phrase_occurrences > 0:
                doc_matches[doc_id] = phrase_occurrences

        elapsed_ms = (time.perf_counter() - start_t) * 1000.0
        return {
            "query": phrase,
            "query_type": "phrase",
            "matches_count": sum(doc_matches.values()),
            "matching_documents_count": len(doc_matches),
            "doc_matches": doc_matches,
            "latency_ms": round(elapsed_ms, 4)
        }

    def get_memory_size_bytes(self) -> int:
        """Approximates memory footprint of the inverted index."""
        size = sys.getsizeof(self.index)
        for term, postings in self.index.items():
            size += sys.getsizeof(term)
            size += sys.getsizeof(postings)
            for doc_id, pos_list in postings.items():
                size += sys.getsizeof(doc_id)
                size += sys.getsizeof(pos_list)
                size += len(pos_list) * 8
        return size

    def get_statistics(self) -> Dict[str, Any]:
        """Returns structural statistics of the inverted index."""
        return {
            "vocabulary_size": len(self.index),
            "total_tokens_indexed": self.total_tokens,
            "build_time_ms": self.build_time_ms,
            "memory_size_bytes": self.get_memory_size_bytes()
        }
