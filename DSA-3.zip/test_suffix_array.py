"""
Unit Tests for Suffix Array Construction (Prefix Doubling Algorithm).

Test Cases:
1. "banana"
2. "mississippi"
3. "abracadabra"
4. "aaaa" (all identical characters)
5. "" (empty string)
6. "a" (single character)
7. "algorithms"
"""

import unittest
from backend.suffix_array import (
    SuffixArray,
    build_suffix_array,
    build_suffix_array_naive
)


class TestSuffixArray(unittest.TestCase):
    """Verifies correctness of O(n log^2 n) Prefix Doubling Suffix Array."""

    def test_banana(self):
        text = "banana"
        sa = build_suffix_array(text)
        expected = [5, 3, 1, 0, 4, 2]
        self.assertEqual(sa, expected)
        # Suffixes in sorted order:
        # 5: "a"
        # 3: "ana"
        # 1: "anana"
        # 0: "banana"
        # 4: "na"
        # 2: "nana"
        sorted_suffixes = [text[i:] for i in sa]
        self.assertEqual(sorted_suffixes, sorted(sorted_suffixes))

    def test_mississippi(self):
        text = "mississippi"
        sa = build_suffix_array(text)
        naive_sa = build_suffix_array_naive(text)
        self.assertEqual(sa, naive_sa)
        sorted_suffixes = [text[i:] for i in sa]
        self.assertEqual(sorted_suffixes, sorted(sorted_suffixes))

    def test_abracadabra(self):
        text = "abracadabra"
        sa = build_suffix_array(text)
        naive_sa = build_suffix_array_naive(text)
        self.assertEqual(sa, naive_sa)
        sorted_suffixes = [text[i:] for i in sa]
        self.assertEqual(sorted_suffixes, sorted(sorted_suffixes))

    def test_repeated_characters(self):
        text = "aaaa"
        sa = build_suffix_array(text)
        # "a", "aa", "aaa", "aaaa"
        expected = [3, 2, 1, 0]
        self.assertEqual(sa, expected)

    def test_empty_string(self):
        text = ""
        sa = build_suffix_array(text)
        self.assertEqual(sa, [])

    def test_single_character(self):
        text = "a"
        sa = build_suffix_array(text)
        self.assertEqual(sa, [0])

    def test_long_text_matches_naive(self):
        text = "data_structures_and_algorithms_suffix_array_indexing"
        sa = build_suffix_array(text)
        naive_sa = build_suffix_array_naive(text)
        self.assertEqual(sa, naive_sa)


if __name__ == "__main__":
    unittest.main()
