@echo off
echo ======================================================================
echo  Full-Text Search Engine on a Suffix-Array Index
echo  College Data Structures and Algorithms (DSA) Project
echo ======================================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH!
    pause
    exit /b 1
)

echo [*] Checking dependencies...
python -m pip install -r requirements.txt

echo.
echo [*] Running automated DSA Unit Tests (23 tests)...
python -m unittest discover tests
if errorlevel 1 (
    echo [ERROR] Unit tests failed!
    pause
    exit /b 1
)

echo.
echo [+] All DSA unit tests passed successfully!
echo.
echo [*] Starting Search Engine Server...
echo [*] Open your web browser at: http://127.0.0.1:5000
echo.
python -m backend.app
pause
