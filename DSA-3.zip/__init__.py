"""Backend package for Full-Text Search Engine on Suffix Array."""
