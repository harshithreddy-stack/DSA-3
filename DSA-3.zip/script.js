/**
 * Full-Text Search Engine on a Suffix-Array Index
 * Course Project - Data Structures & Algorithms
 */

document.addEventListener("DOMContentLoaded", () => {
  // Theme Toggle (Light / Dark)
  const themeToggle = document.getElementById("btn-theme-toggle");
  const currentTheme = localStorage.getItem("dsa_theme") || "light";
  document.documentElement.setAttribute("data-theme", currentTheme);

  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      const active = document.documentElement.getAttribute("data-theme");
      const next = active === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-theme", next);
      localStorage.setItem("dsa_theme", next);
    });
  }

  // Navigation Tabs
  const tabButtons = document.querySelectorAll(".tab-btn");
  const tabSections = document.querySelectorAll(".tab-section");

  tabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const target = btn.getAttribute("data-tab");
      tabButtons.forEach(b => b.classList.remove("active"));
      tabSections.forEach(s => s.classList.remove("active"));

      btn.classList.add("active");
      const targetSection = document.getElementById(target);
      if (targetSection) targetSection.classList.add("active");

      // Lazy load tab data on initial visit
      if (target === "tab-documents" && document.getElementById("documents-grid").children.length === 0) {
        fetchDocuments();
      } else if (target === "tab-visualizer" && document.getElementById("vis-combined-table").querySelector("tbody").children.length === 0) {
        executeVisualizer("banana", "ana");
      } else if (target === "tab-benchmark" && document.getElementById("bench-queries-table").querySelector("tbody").children.length === 0) {
        executeBenchmark();
      }
    });
  });

  // Search Elements
  const searchForm = document.getElementById("search-form");
  const searchInput = document.getElementById("search-input");
  const toggleLcpAccel = document.getElementById("toggle-lcp-accel");
  const searchMetricsBar = document.getElementById("search-metrics-bar");
  const metricLatency = document.getElementById("metric-latency");
  const metricMatches = document.getElementById("metric-matches");
  const metricDocs = document.getElementById("metric-docs");
  const metricComparisons = document.getElementById("metric-comparisons");
  const metricAlgorithm = document.getElementById("metric-algorithm");
  const resultsContainer = document.getElementById("results-container");

  // Visualizer Elements
  const visTextInput = document.getElementById("vis-text-input");
  const visQueryInput = document.getElementById("vis-query-input");
  const btnRunVis = document.getElementById("btn-run-vis");
  const visOrigTable = document.getElementById("vis-original-suffixes-table").querySelector("tbody");
  const visCombinedTable = document.getElementById("vis-combined-table").querySelector("tbody");
  const visDoublingSteps = document.getElementById("vis-doubling-steps");
  const visKasaiTable = document.getElementById("vis-kasai-table").querySelector("tbody");
  const visBsTable = document.getElementById("vis-bs-table").querySelector("tbody");
  const visBsStats = document.getElementById("vis-bs-stats");

  // Benchmark Elements
  const btnRunBenchmark = document.getElementById("btn-run-benchmark");
  const benchSaBuildTime = document.getElementById("bench-sa-build-time");
  const benchSaDetails = document.getElementById("bench-sa-details");
  const benchSaMemory = document.getElementById("bench-sa-memory");
  const benchInvBuildTime = document.getElementById("bench-inv-build-time");
  const benchInvMemory = document.getElementById("bench-inv-memory");
  const benchQueriesTable = document.getElementById("bench-queries-table").querySelector("tbody");
  const benchCharSavingsTable = document.getElementById("bench-char-savings-table").querySelector("tbody");

  // Rebuild & Stats Buttons
  const btnRebuildIndex = document.getElementById("btn-rebuild-index");
  const btnViewStats = document.getElementById("btn-view-stats");

  // Modals
  const docModal = document.getElementById("doc-modal");
  const modalClose = document.getElementById("modal-close");
  const modalDocTitle = document.getElementById("modal-doc-title");
  const modalDocMeta = document.getElementById("modal-doc-meta");
  const modalDocContent = document.getElementById("modal-doc-content");

  const statsModal = document.getElementById("stats-modal");
  const statsModalClose = document.getElementById("stats-modal-close");
  const statsModalBody = document.getElementById("stats-modal-body");

  // 1. Search Form Submission
  searchForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const query = searchInput.value.trim();
    if (!query) return;

    const searchType = document.querySelector('input[name="search_type"]:checked').value;
    const useLcp = toggleLcpAccel.checked;

    resultsContainer.innerHTML = `<div class="placeholder-state"><p class="placeholder-heading">Searching index for "${escapeHtml(query)}"...</p></div>`;

    try {
      const response = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: query,
          search_type: searchType,
          use_lcp_accel: useLcp
        })
      });

      const data = await response.json();
      displaySearchResults(data);
    } catch (err) {
      resultsContainer.innerHTML = `<div class="placeholder-state"><p style="color:var(--danger)">Error: ${escapeHtml(err.message)}</p></div>`;
    }
  });

  // Query Sample Chips
  document.querySelectorAll(".sample-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      searchInput.value = chip.getAttribute("data-query");
      const mode = chip.getAttribute("data-type") || "substring";
      const radio = document.querySelector(`input[name="search_type"][value="${mode}"]`);
      if (radio) radio.checked = true;
      searchForm.dispatchEvent(new Event("submit"));
    });
  });

  // Display Search Results
  function displaySearchResults(data) {
    searchMetricsBar.style.display = "grid";
    metricLatency.textContent = `${data.latency_ms} ms`;
    metricMatches.textContent = data.total_matches;
    metricDocs.textContent = `${data.document_matches_count} / 10`;
    metricComparisons.textContent = data.character_comparisons;
    metricAlgorithm.textContent = data.algorithm_used.includes("LCP") ? "LCP-Accelerated BS" : "Standard BS";

    if (!data.results || data.results.length === 0) {
      resultsContainer.innerHTML = `
        <div class="placeholder-state">
          <p class="placeholder-heading">No results found for "${escapeHtml(data.query)}"</p>
          <p class="placeholder-sub">The query does not appear in the Suffix Array index. Try another keyword or switch to Substring search.</p>
        </div>
      `;
      return;
    }

    resultsContainer.innerHTML = "";
    data.results.forEach(doc => {
      const item = document.createElement("div");
      item.className = "result-item";

      const titleTag = doc.in_title ? `<span class="tag tag-title">Title Match</span>` : "";
      const snippetsHtml = doc.snippets.map(s => `<div class="snippet-line">${s}</div>`).join("");

      item.innerHTML = `
        <div class="result-head">
          <a href="#" class="result-link" data-doc-id="${doc.doc_id}">${escapeHtml(doc.title)}</a>
          <div class="result-stats-tags">
            ${titleTag}
            <span class="tag tag-matches">${doc.match_count} matches</span>
            <span class="tag tag-score">Score: ${doc.score}</span>
          </div>
        </div>
        <div class="snippet-list">
          ${snippetsHtml}
        </div>
        <div class="result-meta-foot">
          <span>File: ${escapeHtml(doc.filename)} &bull; First Occurrence Offset: ${doc.first_position}</span>
          <span>Click document title to view full text</span>
        </div>
      `;

      item.querySelector(".result-link").addEventListener("click", (e) => {
        e.preventDefault();
        showDocumentModal(doc.doc_id);
      });

      resultsContainer.appendChild(item);
    });
  }

  // 2. Document Corpus Tab
  async function fetchDocuments() {
    const grid = document.getElementById("documents-grid");
    try {
      const res = await fetch("/api/documents");
      const data = await res.json();
      grid.innerHTML = "";

      data.documents.forEach(doc => {
        const tile = document.createElement("div");
        tile.className = "doc-tile";
        tile.innerHTML = `
          <h4>${escapeHtml(doc.title)}</h4>
          <p class="doc-preview-text">${escapeHtml(doc.preview)}</p>
          <div class="doc-tile-footer">
            <span>${doc.word_count} words &bull; ${doc.char_count} chars</span>
            <span>Doc #${doc.doc_id}</span>
          </div>
        `;
        tile.addEventListener("click", () => showDocumentModal(doc.doc_id));
        grid.appendChild(tile);
      });
    } catch (err) {
      grid.innerHTML = `<p style="color:var(--danger)">Error loading documents: ${err.message}</p>`;
    }
  }

  // Document Detail Modal
  async function showDocumentModal(docId) {
    try {
      const res = await fetch(`/api/document/${docId}`);
      const doc = await res.json();
      modalDocTitle.textContent = doc.title;
      modalDocMeta.textContent = `Filename: ${doc.filename} | Document ID: ${doc.doc_id} | Characters: ${doc.char_count} | Words: ${doc.word_count}`;
      modalDocContent.textContent = doc.content;
      docModal.style.display = "flex";
    } catch (err) {
      alert("Error opening document: " + err.message);
    }
  }

  modalClose.addEventListener("click", () => {
    docModal.style.display = "none";
  });

  // 3. Rebuild Index
  btnRebuildIndex.addEventListener("click", async () => {
    btnRebuildIndex.textContent = "Rebuilding...";
    btnRebuildIndex.disabled = true;
    try {
      const res = await fetch("/api/rebuild", { method: "POST" });
      const data = await res.json();
      const s = data.statistics;
      alert(`Index Rebuilt Successfully.\n\nTotal Characters: ${s.total_characters}\nTotal Suffixes: ${s.total_suffixes}\nSuffix Array Build: ${s.sa_build_time_ms} ms\nKasai LCP Build: ${s.lcp_build_time_ms} ms\nTotal Build Time: ${s.total_build_time_ms} ms`);
    } catch (err) {
      alert("Error rebuilding index: " + err.message);
    } finally {
      btnRebuildIndex.textContent = "Rebuild Index";
      btnRebuildIndex.disabled = false;
    }
  });

  // 4. Index Info Modal
  btnViewStats.addEventListener("click", async () => {
    statsModal.style.display = "flex";
    statsModalBody.innerHTML = "<p>Loading statistics...</p>";

    try {
      const res = await fetch("/api/status");
      const data = await res.json();
      const s = data.statistics;
      const inv = s.inverted_index_stats;

      statsModalBody.innerHTML = `
        <table class="clean-table">
          <thead>
            <tr><th>Metric</th><th>Suffix Array Index</th><th>Inverted Index</th></tr>
          </thead>
          <tbody>
            <tr><td>Total Documents</td><td>${s.document_count}</td><td>${s.document_count}</td></tr>
            <tr><td>Total Characters Indexed</td><td>${s.total_characters.toLocaleString()}</td><td>-</td></tr>
            <tr><td>Total Suffixes / Tokens</td><td>${s.total_suffixes.toLocaleString()} suffixes</td><td>${inv.vocabulary_size} words (${inv.total_tokens_indexed} tokens)</td></tr>
            <tr><td>Index Construction Time</td><td><strong>${s.total_build_time_ms} ms</strong> (SA: ${s.sa_build_time_ms}ms, LCP: ${s.lcp_build_time_ms}ms)</td><td><strong>${inv.build_time_ms} ms</strong></td></tr>
            <tr><td>Memory Footprint</td><td><strong>${(s.sa_memory_size_bytes / 1024).toFixed(1)} KB</strong></td><td><strong>${(inv.memory_size_bytes / 1024).toFixed(1)} KB</strong></td></tr>
          </tbody>
        </table>
      `;
    } catch (err) {
      statsModalBody.innerHTML = `<p style="color:var(--danger)">Error: ${err.message}</p>`;
    }
  });

  statsModalClose.addEventListener("click", () => {
    statsModal.style.display = "none";
  });

  window.addEventListener("click", (e) => {
    if (e.target === docModal) docModal.style.display = "none";
    if (e.target === statsModal) statsModal.style.display = "none";
  });

  // 5. Visualizer Controller
  btnRunVis.addEventListener("click", () => {
    const text = visTextInput.value.trim();
    const query = visQueryInput.value.trim();
    if (text) executeVisualizer(text, query);
  });

  document.querySelectorAll(".preset-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      visTextInput.value = btn.getAttribute("data-text");
      visQueryInput.value = btn.getAttribute("data-query");
      executeVisualizer(visTextInput.value, visQueryInput.value);
    });
  });

  async function executeVisualizer(text, query) {
    try {
      const res = await fetch("/api/visualize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, query })
      });
      const data = await res.json();
      if (data.error) {
        alert(data.error);
        return;
      }
      renderVisualizerData(data);
    } catch (err) {
      alert("Error in visualizer: " + err.message);
    }
  }

  function renderVisualizerData(data) {
    // 1. Original Suffixes
    visOrigTable.innerHTML = "";
    for (let i = 0; i < data.text.length; i++) {
      const suffix = data.text.substring(i);
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${i}</td>
        <td><code>${escapeHtml(suffix)}</code></td>
        <td>${suffix.length}</td>
      `;
      visOrigTable.appendChild(row);
    }

    // 2. Sorted Suffix Array & Kasai LCP Table
    visCombinedTable.innerHTML = "";
    data.combined_table.forEach(item => {
      const row = document.createElement("tr");
      if (item.is_match) row.className = "highlight-match";

      const common = (item.rank > 0 && item.lcp > 0)
        ? data.text.substr(item.suffix_index, item.lcp)
        : "-";

      row.innerHTML = `
        <td><strong>${item.rank}</strong></td>
        <td><code>${item.suffix_index}</code></td>
        <td><strong>${item.lcp}</strong></td>
        <td><code>${escapeHtml(common)}</code></td>
        <td><code>${escapeHtml(item.suffix)}</code></td>
        <td>${item.is_match ? '<span style="color:var(--accent-green); font-weight:600;">Yes &bull; [Matches]</span>' : '<span style="color:var(--text-light);">-</span>'}</td>
      `;
      visCombinedTable.appendChild(row);
    });

    // 3. Prefix Doubling Steps
    visDoublingSteps.innerHTML = "";
    if (data.prefix_doubling_steps) {
      data.prefix_doubling_steps.forEach(step => {
        const box = document.createElement("div");
        box.className = "doubling-box";

        const rows = step.table.map(r => `
          <tr>
            <td>${r.sa_pos}</td>
            <td>${r.suffix_idx}</td>
            <td>(${r.rank_pair[0]}, ${r.rank_pair[1]})</td>
            <td><strong>${r.assigned_rank}</strong></td>
            <td><code>${escapeHtml(r.suffix_str)}</code></td>
          </tr>
        `).join("");

        box.innerHTML = `
          <div class="doubling-title">Iteration k = ${step.k} (Compared Prefix Length: ${step.compared_length})</div>
          <table class="clean-table">
            <thead>
              <tr>
                <th>Sorted Pos</th>
                <th>Suffix Index</th>
                <th>Rank Tuple (r1, r2)</th>
                <th>Assigned Rank</th>
                <th>Prefix Sample</th>
              </tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
        `;
        visDoublingSteps.appendChild(box);
      });
    }

    // 4. Kasai Algorithm Trace
    visKasaiTable.innerHTML = "";
    if (data.kasai_trace) {
      data.kasai_trace.forEach(t => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${t.original_index_i}</td>
          <td><code>${escapeHtml(t.suffix_i)}</code></td>
          <td>${t.sa_rank_r}</td>
          <td><code>${escapeHtml(t.predecessor_suffix_j)}</code></td>
          <td><strong>${t.matched_lcp_h}</strong></td>
          <td><code>${escapeHtml(t.common_prefix || "-")}</code></td>
        `;
        visKasaiTable.appendChild(row);
      });
    }

    // 5. Binary Search Trace
    const c = data.comparison;
    visBsStats.innerHTML = `
      <div>Query: <strong>"${escapeHtml(c.query)}"</strong></div>
      <div>Standard BS Comparisons: <strong>${c.std_comparisons}</strong></div>
      <div>LCP-Accelerated Comparisons: <strong style="color:var(--accent-green)">${c.lcp_comparisons}</strong></div>
      <div>Comparisons Saved: <strong style="color:var(--primary)">${c.comparisons_saved}</strong></div>
    `;

    visBsTable.innerHTML = "";
    const trace = data.lcp_binary_search.trace || [];
    trace.forEach((t, idx) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${idx + 1}</td>
        <td>${t.low}</td>
        <td>${t.mid}</td>
        <td>${t.high}</td>
        <td>Case ${t.case || 3}: ${t.action}</td>
        <td>${t.skipped_chars ? `<strong>${t.skipped_chars}</strong> chars` : "-"}</td>
        <td>${t.comps || 0}</td>
      `;
      visBsTable.appendChild(row);
    });
  }

  // 6. Benchmark Runner
  btnRunBenchmark.addEventListener("click", executeBenchmark);

  async function executeBenchmark() {
    btnRunBenchmark.textContent = "Running Benchmark...";
    btnRunBenchmark.disabled = true;

    try {
      const res = await fetch("/api/benchmark");
      const report = await res.json();

      const c = report.inverted_index_comparison.construction_comparison;
      benchSaBuildTime.textContent = `${c.suffix_array_build_time_ms} ms`;
      benchSaDetails.textContent = c.sa_details;
      benchSaMemory.textContent = `Memory: ${(c.sa_memory_bytes / 1024).toFixed(1)} KB`;

      benchInvBuildTime.textContent = `${c.inverted_index_build_time_ms} ms`;
      benchInvMemory.textContent = `Memory: ${(c.inverted_index_memory_bytes / 1024).toFixed(1)} KB`;

      // Query Latencies
      benchQueriesTable.innerHTML = "";
      report.inverted_index_comparison.queries.forEach(q => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td><strong>${escapeHtml(q.category)}</strong></td>
          <td><code>${escapeHtml(q.query)}</code></td>
          <td><strong>${q.sa_latency_ms} ms</strong></td>
          <td>${q.sa_matches}</td>
          <td><strong>${q.inv_latency_ms} ms</strong></td>
          <td>${q.inv_matches}</td>
          <td><span style="font-size:0.75rem; color:var(--text-muted)">SA: ${q.sa_notes} &bull; Inv: ${q.inv_notes}</span></td>
        `;
        benchQueriesTable.appendChild(row);
      });

      // Character Savings
      benchCharSavingsTable.innerHTML = "";
      report.binary_search_comparison.forEach(item => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td><code>${escapeHtml(item.query)}</code></td>
          <td>${item.std_comparisons}</td>
          <td><strong style="color:var(--accent-green)">${item.lcp_comparisons}</strong></td>
          <td><strong>+${item.comparisons_saved}</strong></td>
          <td><strong>${item.percent_saved}</strong></td>
        `;
        benchCharSavingsTable.appendChild(row);
      });
    } catch (err) {
      alert("Error running benchmark: " + err.message);
    } finally {
      btnRunBenchmark.textContent = "Run Live Benchmark";
      btnRunBenchmark.disabled = false;
    }
  }

  function escapeHtml(text) {
    if (!text) return "";
    const div = document.createElement("div");
    div.textContent = String(text);
    return div.innerHTML;
  }
});
