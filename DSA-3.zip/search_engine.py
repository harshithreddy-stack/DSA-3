"""
Search Engine Coordinating Suffix Array, Kasai LCP, Binary Search, and Ranking.

Full-Text Search Engine on a Suffix-Array Index
A College Data Structures and Algorithms (DSA) Project.

Architecture:
1. Document Collection -> Concatenated Corpus with Sentinels
2. Suffix Array Construction via Prefix Doubling O(n log^2 n)
3. LCP Array Construction via Kasai's Algorithm O(n)
4. RMQ Sparse Table Construction O(n log n)
5. Pattern Search: Standard Binary Search O(m log n) OR LCP-Accelerated O(m + log n)
6. Global Position -> Document Mapping O(log D)
7. Relevance Scoring & Custom Merge Sort O(K log K)
"""

import time
import sys
from typing import List, Dict, Any, Tuple, Optional
from .suffix_array import SuffixArray
from .lcp import LCPArray
from .binary_search import (
    standard_binary_search,
    lcp_accelerated_binary_search,
    SearchResult
)
from .document_manager import DocumentManager, Document
from .ranking import Ranker, ScoredDocument
from .inverted_index import InvertedIndex


class SearchEngine:
    """
    Core Full-Text Search Engine implementing Suffix Array and LCP index.
    """

    def __init__(self, doc_dir: Optional[str] = None):
        self.doc_manager = DocumentManager(doc_dir)
        self.suffix_array_obj: Optional[SuffixArray] = None
        self.lcp_obj: Optional[LCPArray] = None
        self.inverted_index = InvertedIndex()
        self.ranker = Ranker()

        # Performance and index statistics
        self.sa_build_time_ms: float = 0.0
        self.lcp_build_time_ms: float = 0.0
        self.total_build_time_ms: float = 0.0
        self.total_suffixes: int = 0
        self.corpus_length: int = 0
        self.is_indexed: bool = False

        if self.doc_manager.documents:
            self.build_index()

    def build_index(self):
        """
        Builds the entire DSA indexing pipeline:
        1. Suffix Array via Prefix Doubling: O(n log^2 n)
        2. Kasai's LCP Array: O(n)
        3. RMQ Sparse Table: O(n log n)
        4. Inverted Index (for DSA comparison)
        """
        start_total = time.perf_counter()

        text = self.doc_manager.normalized_text
        self.corpus_length = len(text)
        self.total_suffixes = self.corpus_length

        if self.corpus_length == 0:
            self.is_indexed = True
            return

        # 1. Suffix Array construction
        start_sa = time.perf_counter()
        self.suffix_array_obj = SuffixArray(text)
        self.sa_build_time_ms = round((time.perf_counter() - start_sa) * 1000.0, 3)

        # 2. Kasai's LCP array construction
        start_lcp = time.perf_counter()
        self.lcp_obj = LCPArray(text, self.suffix_array_obj.get_suffix_array())
        self.lcp_build_time_ms = round((time.perf_counter() - start_lcp) * 1000.0, 3)

        self.total_build_time_ms = round((time.perf_counter() - start_total) * 1000.0, 3)

        # 3. Build Inverted Index for baseline DSA comparison
        self.inverted_index.build(self.doc_manager.documents)

        self.is_indexed = True

    def search(
        self,
        query: str,
        search_type: str = "substring",
        use_lcp_accel: bool = True
    ) -> Dict[str, Any]:
        """
        Executes a pattern search over the Suffix Array index.
        
        Args:
            query: The search query string.
            search_type: 'substring', 'prefix', or 'phrase'.
            use_lcp_accel: Whether to use LCP-accelerated binary search or standard binary search.
        
        Returns:
            Dictionary containing ranked documents, query latency, comparison count,
            DSA match details, and execution metadata.
        """
        start_t = time.perf_counter()
        q_norm = query.lower().strip()

        if not q_norm or not self.is_indexed or self.corpus_length == 0:
            return {
                "query": query,
                "search_type": search_type,
                "use_lcp_accel": use_lcp_accel,
                "latency_ms": 0.0,
                "total_matches": 0,
                "document_matches_count": 0,
                "character_comparisons": 0,
                "sa_range": [-1, -1],
                "results": [],
                "merge_sort_comparisons": 0
            }

        text = self.doc_manager.normalized_text
        sa = self.suffix_array_obj.get_suffix_array()

        # Step 1: Perform Binary Search over Suffix Array
        if use_lcp_accel and self.lcp_obj:
            sa_res: SearchResult = lcp_accelerated_binary_search(
                text=text,
                sa=sa,
                lcp_obj=self.lcp_obj,
                pattern=q_norm
            )
        else:
            sa_res = standard_binary_search(
                text=text,
                sa=sa,
                pattern=q_norm
            )

        raw_match_positions = sa_res.matches

        # Step 2: Filter match positions based on search type
        # For 'prefix' search: matches must occur at word boundaries
        filtered_matches = []
        for pos in raw_match_positions:
            if search_type == "prefix":
                # Check if preceding character is non-alphanumeric or start of document
                if pos == 0:
                    filtered_matches.append(pos)
                else:
                    prev_char = text[pos - 1]
                    if not prev_char.isalnum():
                        filtered_matches.append(pos)
            else:
                # Substring and Phrase search: all suffix matches count directly
                filtered_matches.append(pos)

        # Step 3: Map Global Positions -> Document ID & Local Offset
        doc_matches: List[Tuple[Document, int]] = []
        for pos in filtered_matches:
            mapping = self.doc_manager.map_position_to_document(pos, len(q_norm))
            if mapping:
                doc_matches.append(mapping)

        # Step 4: Rank results using DSA scoring and Merge Sort
        ranked_docs, sort_comps = self.ranker.rank_results(
            raw_matches=doc_matches,
            query=query,
            doc_manager=self.doc_manager,
            match_len=len(q_norm)
        )

        elapsed_ms = (time.perf_counter() - start_t) * 1000.0

        return {
            "query": query,
            "search_type": search_type,
            "use_lcp_accel": use_lcp_accel,
            "algorithm_used": "LCP-Accelerated Binary Search O(m + log n)" if use_lcp_accel else "Standard Binary Search O(m log n)",
            "latency_ms": round(elapsed_ms, 4),
            "total_matches": len(doc_matches),
            "document_matches_count": len(ranked_docs),
            "character_comparisons": sa_res.comparisons,
            "sa_range": [sa_res.left, sa_res.right],
            "merge_sort_comparisons": sort_comps,
            "results": [d.to_dict() for d in ranked_docs]
        }

    def get_index_memory_size_bytes(self) -> int:
        """Calculates total memory footprint of Suffix Array + LCP + Sparse Table."""
        size = 0
        if self.suffix_array_obj:
            size += sys.getsizeof(self.suffix_array_obj.sa)
            size += len(self.suffix_array_obj.sa) * 8
        if self.lcp_obj:
            size += sys.getsizeof(self.lcp_obj.lcp)
            size += len(self.lcp_obj.lcp) * 8
            size += sys.getsizeof(self.lcp_obj.rank)
            size += len(self.lcp_obj.rank) * 8
            # Sparse table size
            for row in self.lcp_obj.sparse_table:
                size += sys.getsizeof(row) + len(row) * 8
        return size

    def get_statistics(self) -> Dict[str, Any]:
        """Returns comprehensive statistics of the search engine and DSA index."""
        return {
            "document_count": len(self.doc_manager.documents),
            "total_characters": self.corpus_length,
            "total_suffixes": self.total_suffixes,
            "sa_build_time_ms": self.sa_build_time_ms,
            "lcp_build_time_ms": self.lcp_build_time_ms,
            "total_build_time_ms": self.total_build_time_ms,
            "sa_memory_size_bytes": self.get_index_memory_size_bytes(),
            "inverted_index_stats": self.inverted_index.get_statistics()
        }
