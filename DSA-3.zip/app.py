"""
Flask Web Application for Full-Text Search Engine on a Suffix-Array Index.

Endpoints:
- GET  /                     -> Serves frontend UI
- GET  /api/status           -> Search engine status and memory metrics
- POST /api/search           -> Execute pattern search (substring, prefix, phrase)
- POST /api/rebuild          -> Rebuild Suffix Array and LCP index
- POST /api/visualize        -> Step-by-step DSA visualizer for custom strings (e.g. 'banana')
- GET  /api/benchmark        -> Live benchmark report (Suffix Array vs Inverted Index)
- GET  /api/documents        -> List indexed documents
- GET  /api/document/<id>    -> Retrieve full document content
"""

import os
import sys
from flask import Flask, request, jsonify, send_from_directory

from .search_engine import SearchEngine
from .suffix_array import SuffixArray
from .lcp import LCPArray
from .binary_search import standard_binary_search, lcp_accelerated_binary_search
from .benchmark import BenchmarkRunner

# Paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")
DOCS_DIR = os.path.join(BASE_DIR, "data", "documents")

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")

@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return response

# Initialize search engine on startup
engine = SearchEngine(DOCS_DIR)
print(f"Loaded {len(engine.doc_manager.documents)} documents ({engine.corpus_length} characters).")


@app.route("/")
def index():
    """Serves the main frontend dashboard."""
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.route("/<path:path>")
def static_files(path):
    """Serves static assets (css, js)."""
    return send_from_directory(FRONTEND_DIR, path)


@app.route("/api/status", methods=["GET"])
def get_status():
    """Returns engine health, indexed corpus size, and memory usage."""
    stats = engine.get_statistics()
    return jsonify({
        "status": "online",
        "engine": "Suffix Array + Kasai LCP",
        "statistics": stats
    })


@app.route("/api/search", methods=["POST"])
def search():
    """
    Executes a search query over the Suffix Array index.
    Body:
        query: str
        search_type: 'substring' | 'prefix' | 'phrase' (default: 'substring')
        use_lcp_accel: bool (default: true)
    """
    data = request.get_json(force=True, silent=True) or {}
    query = data.get("query", "").strip()
    search_type = data.get("search_type", "substring")
    use_lcp_accel = data.get("use_lcp_accel", True)

    if not query:
        return jsonify({
            "error": "Query cannot be empty",
            "results": [],
            "total_matches": 0
        }), 400

    results = engine.search(
        query=query,
        search_type=search_type,
        use_lcp_accel=use_lcp_accel
    )
    return jsonify(results)


@app.route("/api/rebuild", methods=["POST"])
def rebuild_index():
    """Rebuilds the Suffix Array and LCP index from the documents directory."""
    engine.doc_manager.load_directory(DOCS_DIR)
    engine.build_index()
    stats = engine.get_statistics()
    return jsonify({
        "message": "Index rebuilt successfully",
        "statistics": stats
    })


@app.route("/api/visualize", methods=["POST"])
def visualize():
    """
    DSA Educational Visualizer Endpoint.
    Accepts small strings (e.g. 'banana', 'mississippi', 'algorithms')
    and returns step-by-step Suffix Array construction, Kasai LCP calculation,
    and binary search traces.
    """
    data = request.get_json(force=True, silent=True) or {}
    text = data.get("text", "banana").strip()
    query = data.get("query", "ana").strip()

    # Cap string length for visualization to prevent UI freezing
    if len(text) > 120:
        return jsonify({"error": "For visualization, please provide a string of length <= 120."}), 400

    # 1. Suffix Array via Prefix Doubling
    sa_obj = SuffixArray(text)
    sa = sa_obj.get_suffix_array()
    sa_vis = sa_obj.get_visualization_data()

    # 2. Kasai's LCP Array
    lcp_obj = LCPArray(text, sa)
    lcp = lcp_obj.get_lcp_array()
    lcp_vis = lcp_obj.get_visualization_data()

    # 3. Binary Search simulation on the custom string
    std_search = standard_binary_search(text, sa, query)
    lcp_search = lcp_accelerated_binary_search(text, sa, lcp_obj, query)

    # 4. Summary table combining Suffix Array and LCP
    combined_table = []
    for r in range(len(sa)):
        idx = sa[r]
        suffix_str = text[idx:]
        lcp_val = lcp[r]
        combined_table.append({
            "rank": r,
            "suffix_index": idx,
            "lcp": lcp_val,
            "suffix": suffix_str,
            "is_match": idx in std_search.matches
        })

    return jsonify({
        "text": text,
        "query": query,
        "length": len(text),
        "suffix_array": sa,
        "lcp_array": lcp,
        "combined_table": combined_table,
        "prefix_doubling_steps": sa_vis["history"],
        "kasai_trace": lcp_vis["trace"],
        "standard_binary_search": std_search.to_dict(),
        "lcp_binary_search": lcp_search.to_dict(),
        "comparison": {
            "query": query,
            "std_comparisons": std_search.comparisons,
            "lcp_comparisons": lcp_search.comparisons,
            "comparisons_saved": max(0, std_search.comparisons - lcp_search.comparisons)
        }
    })


@app.route("/api/benchmark", methods=["GET"])
def get_benchmark():
    """Runs live performance benchmarks and returns comparative evaluation."""
    benchmarker = BenchmarkRunner(engine)
    report = benchmarker.generate_full_report()
    return jsonify(report)


@app.route("/api/documents", methods=["GET"])
def get_documents():
    """Returns list of indexed documents with summary metrics."""
    return jsonify({
        "total_documents": len(engine.doc_manager.documents),
        "documents": [d.to_dict() for d in engine.doc_manager.documents]
    })


@app.route("/api/document/<int:doc_id>", methods=["GET"])
def get_document(doc_id):
    """Retrieves full text of a specific document."""
    doc = engine.doc_manager.doc_map.get(doc_id)
    if not doc:
        return jsonify({"error": "Document not found"}), 404
    return jsonify({
        "doc_id": doc.doc_id,
        "title": doc.title,
        "filename": doc.filename,
        "char_count": doc.char_count,
        "word_count": doc.word_count,
        "content": doc.content
    })


def main():
    port = int(os.environ.get("PORT", 5000))
    print(f"Running search engine at http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)


if __name__ == "__main__":
    main()
