# Viva Voce & Academic Defense Guide
## Project: Full-Text Search Engine on a Suffix-Array Index
### Advanced Data Structures and Algorithms (DSA)

This document contains 35 in-depth viva questions and detailed answers designed for comprehensive academic defense, professor evaluation, and technical interviews.

---

### Q1. What is a Suffix?
**Answer:**  
Given a string $S$ of length $n$ indexed from $0$ to $n - 1$, a **suffix** is a substring that starts at any position $i$ ($0 \le i < n$) and extends to the very end of the string ($n - 1$). It is denoted as $S[i \dots n-1]$.
- A string of length $n$ contains exactly $n$ non-empty suffixes.
- **Example:** For the string `"banana"` ($n = 6$):
  - Suffix 0: `"banana"`
  - Suffix 1: `"anana"`
  - Suffix 2: `"nana"`
  - Suffix 3: `"ana"`
  - Suffix 4: `"na"`
  - Suffix 5: `"a"`

---

### Q2. What is a Suffix Array?
**Answer:**  
A **Suffix Array** ($SA$) is a sorted array of integers representing the starting indices of all suffixes of a string, arranged in lexicographical (alphabetical) order.
- Instead of physically storing $n$ strings of lengths up to $n$ (which would consume $O(n^2)$ space), a Suffix Array stores only the integer starting positions, consuming compact $O(n)$ space.
- **Example:** For `"banana"`:
  | Sorted Suffix | Original Index |
  | :--- | :--- |
  | `"a"` | 5 |
  | `"ana"` | 3 |
  | `"anana"` | 1 |
  | `"banana"` | 0 |
  | `"na"` | 4 |
  | `"nana"` | 2 |
  - Therefore, $SA = [5, 3, 1, 0, 4, 2]$.

---

### Q3. Why do we sort suffixes?
**Answer:**  
Sorting suffixes transforms an unstructured linear string into a globally ordered index:
1. **Contiguous Occurrences:** Any substring $P$ appearing in text $S$ must be a prefix of one or more suffixes of $S$. Because the Suffix Array is sorted, all suffixes having prefix $P$ form a single **contiguous interval** $[L, R]$ in $SA$.
2. **Binary Search Capability:** Because the array is ordered, we can locate occurrences of any pattern $P$ of length $m$ in $O(m \log n)$ time using Binary Search, rather than scanning the entire text in $O(n)$ time.

---

### Q4. How is a Suffix Array constructed?
**Answer:**  
There are three primary approaches to constructing a Suffix Array:
1. **Naive Sorting:** Generate all $n$ suffixes and sort them using standard comparison sort. Comparing two suffixes takes $O(n)$ time; sorting takes $O(n \log n)$ comparisons. Total time: $O(n^2 \log n)$.
2. **Prefix Doubling / Ranking (Manber-Myers Algorithm):** Iteratively sort suffixes based on prefixes of length $1, 2, 4, 8, \dots, 2^k$. Total time: $O(n \log^2 n)$ with comparison sort or $O(n \log n)$ with radix sort.
3. **Linear Time Algorithms (DC3 / Skew / SA-IS):** Divide-and-conquer or induced sorting achieving $O(n)$ time, though with higher implementation complexity and constant factors.
*In this project, we implement the foundational $O(n \log^2 n)$ Prefix Doubling algorithm from scratch.*

---

### Q5. What is the doubling technique (Manber-Myers)?
**Answer:**  
The **prefix doubling technique** avoids comparing full suffixes by sorting them in stages of powers of two:
1. At step $k = 0$, sort suffixes by their first character (prefix of length $2^0 = 1$) and assign an initial integer rank.
2. In subsequent rounds ($k = 1, 2, 4, 8, \dots < n$), each suffix $i$ is compared by looking at a prefix of length $2k$.
3. A prefix of length $2k$ starting at $i$ is composed of:
   - The first half of length $k$ starting at $i$: its rank is already known as $\text{rank}[i]$.
   - The second half of length $k$ starting at $i + k$: its rank is already known as $\text{rank}[i + k]$ (or $-1$ if $i + k \ge n$).
4. Thus, comparing two prefixes of length $2k$ reduces to comparing two pairs of integers:
   $$(\text{rank}[i], \text{rank}[i + k]) \quad \text{vs} \quad (\text{rank}[j], \text{rank}[j + k])$$
5. Suffixes are sorted by these 2-tuples and reassigned updated ranks for the next doubling round.

---

### Q6. What is the complexity of Prefix Doubling Suffix Array construction?
**Answer:**  
- **Time Complexity:** $O(n \log^2 n)$
  - The length of prefix doubles each step ($1, 2, 4, \dots, 2^k$). The number of iterations is $\lceil \log_2 n \rceil$.
  - In each iteration, $n$ integer pairs are sorted. Using comparison sort (e.g., MergeSort or Timsort on 2-tuples), sorting takes $O(n \log n)$ comparisons.
  - Overall time: $O(n \log n) \times \log_2 n = O(n \log^2 n)$.
- **Space Complexity:** $O(n)$
  - Requires integer arrays for $SA$, rank, and temporary ranks.

---

### Q7. What is LCP?
**Answer:**  
**LCP** stands for **Longest Common Prefix**.
- Given two strings $A$ and $B$, $\text{LCP}(A, B)$ is the length of the longest initial substring shared by both strings.
  - Example: $\text{LCP}(\text{"algorithm"}, \text{"algebra"}) = 3$ (common prefix `"alg"`).
- In the context of a Suffix Array, the **LCP Array** is an array of size $n$ where $LCP[i]$ denotes the length of the longest common prefix between consecutive sorted suffixes $SA[i - 1]$ and $SA[i]$:
  $$LCP[i] = \text{LCP}(S[SA[i-1] \dots n-1], S[SA[i] \dots n-1])$$
  By convention, $LCP[0] = 0$.

---

### Q8. What is Kasai's Algorithm?
**Answer:**  
Kasai's Algorithm is an ingenious linear-time $O(n)$ algorithm that computes the entire LCP array given the text $S$ and its Suffix Array $SA$.
- **Mechanism:** Instead of computing LCP in the sorted order of $SA$ (which could take $O(n^2)$), Kasai's algorithm processes suffixes in their **original textual order** ($i = 0, 1, 2, \dots, n-1$).
- Using an inverse suffix array $\text{rank}$ (where $\text{rank}[SA[r]] = r$), it identifies the suffix $j = SA[\text{rank}[i] - 1]$ that appears immediately before suffix $i$ in $SA$.
- It matches characters between suffix $i$ and suffix $j$ to determine $h = \text{LCP}(i, j)$.
- When advancing from suffix $i$ to suffix $i + 1$, Kasai establishes that suffix $i + 1$ and its predecessor share at least $h - 1$ characters. Thus, character comparisons for the next suffix can safely start at offset $h - 1$!

---

### Q9. Why does Kasai's Algorithm run in $O(n)$ time?
**Answer:**  
Let $h$ be the common prefix counter:
1. $h$ begins at $0$ and can never exceed $n$ (since no suffix has length $> n$).
2. In each iteration for suffix $i$, $h$ decreases by at most $1$ ($h \leftarrow \max(0, h - 1)$). Across all $n$ iterations, $h$ can decrease at most $n$ times.
3. For $h$ to increase during character matching, every increment of $h$ requires a successful character comparison.
4. Because $h \le n$ and the total decrease in $h$ is at most $n$, the total number of increments to $h$ over the entire algorithm cannot exceed $2n$.
5. Therefore, the total number of character comparisons across all $n$ suffixes is strictly bounded by $2n$, proving a strict $O(n)$ linear runtime.

---

### Q10. What is Binary Search?
**Answer:**  
Binary Search is an optimal search algorithm operating on sorted sequences with a time complexity of $O(\log n)$.
- It repeatedly inspects the middle element $M = (L + R) // 2$ of the current search interval $[L, R]$.
- Based on whether the target element is smaller or greater than the middle element, it discards half of the search interval in each step until the element is located or the interval is exhausted.

---

### Q11. Why can Binary Search be used on a Suffix Array?
**Answer:**  
Because the Suffix Array orders all suffixes of the text in strict lexicographical order:
- All suffixes that begin with a query pattern $P$ are grouped together in a single contiguous range $[L, R]$ in $SA$.
- Standard Binary Search can be applied twice:
  1. Once to find the **lower bound** $L$: the first suffix in $SA$ where $\text{suffix} \ge P$.
  2. Once to find the **upper bound** $R$: the last suffix in $SA$ where $\text{suffix}$ starts with $P$.
- The number of occurrences of pattern $P$ is immediately given by $R - L + 1$, and their starting positions in the text are $\{ SA[i] \mid i \in [L, R] \}$.

---

### Q12. What is LCP-Accelerated Binary Search?
**Answer:**  
In standard Binary Search on a Suffix Array, each probe compares query pattern $P$ against suffix $SA[M]$, which may take up to $m = |P|$ character comparisons per probe, yielding $O(m \log n)$ total time.
- **LCP Acceleration (Manber & Myers):**
  By maintaining $l = \text{LCP}(P, SA[L])$ and $r = \text{LCP}(P, SA[R])$, and querying the precomputed LCP between suffixes $SA[L]$ and $SA[M]$ (denoted $lcp\_lm$ via Range Minimum Query in $O(1)$), we can deduce the outcome of the comparison without re-comparing characters:
  - If $lcp\_lm > l$: Mid shares more with Low than Pattern does. Mid is on the same side of Pattern as Low. **Zero character comparisons!**
  - If $lcp\_lm < l$: Mid diverges earlier than Pattern. Mid is strictly greater than Pattern. **Zero character comparisons!**
  - If $lcp\_lm == l$: Pattern and Mid match for at least $l$ characters. We only compare characters starting from index $l$ onward!
- This reduces character comparisons from $O(m \log n)$ to $O(m + \log n)$.

---

### Q13. Why does LCP improve searching?
**Answer:**  
LCP eliminates **redundant character comparisons**.
- In standard binary search, when comparing against midpoint after midpoint, the algorithm repeatedly compares the same initial characters of the pattern (e.g., comparing the first 10 characters over and over again).
- LCP information guarantees that the first $k$ characters are already identical. The search can skip directly to index $k$ or bypass the comparison entirely, yielding substantial empirical speedups (as proven in our benchmark: up to 58% fewer character comparisons).

---

### Q14. What is lexicographical comparison?
**Answer:**  
Lexicographical comparison is alphabetical order extended to arbitrary character sets:
- Two strings $A$ and $B$ are compared character by character from left to right.
- At the first index $k$ where $A[k] \ne B[k]$, the string whose character has smaller ASCII value is considered smaller ($A < B$ if $A[k] < B[k]$).
- If one string is a prefix of the other, the shorter string is lexicographically smaller (e.g., `"app"` < `"apple"`).

---

### Q15. What is Substring Search?
**Answer:**  
Substring search finds all occurrences of an arbitrary pattern $P$ anywhere within a text corpus, regardless of whether $P$ appears at the start, middle, or end of a word.
- **Suffix Array Advantage:** Any substring of a text is a prefix of some suffix. Thus, Suffix Arrays support arbitrary substring search natively in $O(m \log n)$ or $O(m + \log n)$.
- An Inverted Index cannot perform arbitrary substring searches efficiently without scanning the entire vocabulary.

---

### Q16. What is Prefix Search?
**Answer:**  
Prefix search locates words or tokens that begin with a specified character sequence (e.g., query `"comp"` matching `"computer"`, `"computation"`).
- In our Suffix Array engine, prefix search filters matches by verifying that the preceding character in the text is a word boundary (such as a space, newline, or punctuation).

---

### Q17. What is Phrase Search?
**Answer:**  
Phrase search looks for an exact multi-word sequence (e.g., `"machine learning"` or `"operating system"`).
- In our Suffix Array engine, the entire corpus text includes spaces between words. Therefore, a multi-word phrase is searched as a single continuous string pattern directly across the Suffix Array without requiring multi-list intersection.

---

### Q18. Why is Document Mapping needed?
**Answer:**  
To search across multiple documents with a single Suffix Array, all documents are concatenated into one continuous string separated by unique delimiter sentinels (`\x00`).
- When binary search discovers a match at global position $G$ in the concatenated string:
  1. We must determine which document contains position $G$.
  2. We must calculate the local offset within that document: $\text{local\_offset} = G - \text{doc\_start}$.
  3. We must verify that the match does not cross the document delimiter boundary.
- We achieve this in $O(\log D)$ time using Binary Search over document boundary intervals.

---

### Q19. What is an Inverted Index?
**Answer:**  
An Inverted Index is a classical information retrieval data structure that maps discrete words (tokens) to a "postings list" of document IDs and token positions where the word occurs:
$$\text{"algorithm"} \longrightarrow \{ \text{Doc 1}: [14, 82], \text{Doc 2}: [5, 41] \}$$
- It is the standard architecture behind web search engines (e.g., Lucene, Elasticsearch) for word-level indexing.

---

### Q20. What are the key differences between Suffix Array and Inverted Index?
**Answer:**  
| Feature | Suffix Array | Inverted Index |
| :--- | :--- | :--- |
| **Indexing Unit** | Every character position / suffix | Discrete words / tokens |
| **Arbitrary Substring Search** | **Native** in $O(m \log n)$ | Requires full lexicon scan $O(V)$ or n-grams |
| **Exact Word Search** | $O(m \log n)$ binary search | **$O(1)$** average hash lookup |
| **Phrase Search** | Direct single string match | Positional intersection of postings lists |
| **Index Construction** | $O(n \log^2 n)$ or $O(n)$ | $O(\text{Tokens})$ linear tokenization |
| **Space Consumption** | Exactly $O(n)$ integers | $O(\text{Vocabulary} + \text{Postings})$ |
| **Application Domains** | Bioinformatics, genome search, full-text pattern matching | Keyword web search, text document retrieval |

---

### Q21. What is Time Complexity?
**Answer:**  
Time complexity expresses the asymptotic upper bound on the number of computational steps executed by an algorithm as a function of input size $n$. Expressed in Big-O notation, it characterizes algorithmic scalability independently of hardware differences.

---

### Q22. What is Space Complexity?
**Answer:**  
Space complexity represents the asymptotic amount of memory (auxiliary space) required by an algorithm during execution as a function of input size $n$.
- For our Suffix Array: $O(n)$ auxiliary integers for $SA$ and $LCP$.
- For the Sparse Table RMQ: $O(n \log n)$ integers.

---

### Q23. What is Query Latency?
**Answer:**  
Query latency is the time elapsed between the dispatch of a search request and the return of ranked results.
- In our engine, query latency is measured in milliseconds ($ms$).
- Suffix Array search executes in sub-millisecond time ($0.05 \dots 0.20$ ms) because it only searches via binary search without scanning the corpus.

---

### Q24. What is Index Construction Time?
**Answer:**  
Index construction time is the offline preprocessing time required to build data structures ($SA$, $LCP$, Sparse Table) before any queries can be answered.
- Suffix Array: ~130 ms for ~20,000 characters.
- Kasai LCP: ~30 ms for ~20,000 characters.
- Total Index Time: ~165 ms. Once built, millions of queries can be answered instantaneously.

---

### Q25. What are the limitations of Suffix Arrays?
**Answer:**  
1. **Dynamic Updates:** Inserting or deleting characters in the text typically requires rebuilding or costly shifting of suffix indices. Suffix Arrays are best suited for static or read-heavy corpora.
2. **Construction Overhead:** Suffix Array construction takes more CPU cycles than simple word tokenization.
3. **Memory for Large Scales:** For gigabytes of text, an in-memory Suffix Array requiring 4 or 8 bytes per character requires compressed representations (such as FM-index or Compressed Suffix Arrays using Burrows-Wheeler Transform).

---

### Q26. Why is preprocessing necessary?
**Answer:**  
Without preprocessing, searching for a pattern in text of size $n$ requires linear scanning ($O(n)$) per query (e.g., via KMP or Boyer-Moore). If there are $Q$ queries, total time is $O(Q \cdot n)$.
- Preprocessing the text into a Suffix Array costs $O(n \log^2 n)$ once.
- Every subsequent query takes only $O(m \log n)$ or $O(m + \log n)$.
- When $Q$ is large, preprocessing provides orders of magnitude improvement in throughput.

---

### Q27. How are search results ranked?
**Answer:**  
When raw occurrences are mapped to documents, a DSA-based scoring model computes a relevance score for each document:
$$\text{Score}(d) = (10 \times \text{Occurrences}) + (25 \times \text{InTitle}) + \frac{15 \times 1000}{1000 + \text{FirstPosition}} + (2 \times \text{Density})$$
- Documents are sorted in descending order of score using a **custom MergeSort** algorithm ($O(K \log K)$), demonstrating fundamental DSA sorting principles.

---

### Q28. How is the LCP array generated?
**Answer:**  
The LCP array is generated using Kasai's algorithm:
1. Construct inverse array $\text{rank}$ where $\text{rank}[SA[r]] = r$.
2. Iterate $i$ from $0$ to $n - 1$.
3. If $\text{rank}[i] > 0$, identify suffix $j = SA[\text{rank}[i] - 1]$.
4. Match characters starting from offset $h$ between suffix $i$ and suffix $j$ until a mismatch occurs.
5. Set $LCP[\text{rank}[i]] = h$.
6. Decrement $h$ by 1 for the next iteration if $h > 0$.

---

### Q29. What happens if no suffix matches?
**Answer:**  
In binary search:
- The lower bound probe finds that the query is either smaller than all suffixes or larger than all suffixes, or the suffix at the computed lower bound does not begin with the pattern.
- The search immediately returns an empty interval $[ -1, -1 ]$ with $0$ matches and $0$ documents in $O(\log n)$ time, without scanning the text.

---

### Q30. What are possible future improvements?
**Answer:**  
1. **Compressed Suffix Arrays / FM-Index:** Employ the Burrows-Wheeler Transform (BWT) with wavelet trees to reduce memory to near the text compression limit.
2. **Linear-time SA Construction (SA-IS):** Implement the Two-Stage Induced Sorting algorithm for $O(n)$ construction time.
3. **Fuzzy Search / Levenshtein Distance:** Combine the Suffix Array with a Trie or Levenshtein automaton to support spelling correction and approximate pattern matching.
4. **Distributed Sharding:** Partition document collections across multiple cluster nodes with merged query aggregation.

---

### Q31. What is Range Minimum Query (RMQ) and how does it relate to LCP?
**Answer:**  
The LCP between any two arbitrary suffixes $SA[i]$ and $SA[j]$ ($i < j$) is the minimum value in the subarray $LCP[i + 1 \dots j]$:
$$\text{LCP}(SA[i], SA[j]) = \min_{i < k \le j} LCP[k]$$
By building a **Sparse Table** over $LCP$ in $O(n \log n)$ time, any arbitrary pairwise LCP can be answered in $O(1)$ constant time. This powers the Manber-Myers LCP-accelerated binary search.

---

### Q32. What is a sentinel character?
**Answer:**  
A sentinel character (often denoted as `$` or ASCII `\x00`) is a special terminal symbol appended to the text that is defined to be lexicographically smaller than any character in the alphabet.
- It ensures that no suffix is a proper prefix of any other suffix, eliminating boundary checks during string comparisons.

---

### Q33. How does the engine prevent matches from spanning across documents?
**Answer:**  
Documents are joined using the delimiter `\x00`. During document mapping:
- If a match begins at position $G$ with pattern length $m$, we check whether $G + m \le \text{doc\_end}$.
- If $G + m > \text{doc\_end}$, the match spans across the delimiter and is immediately discarded.

---

### Q34. How does the Suffix Array compare with a Suffix Tree?
**Answer:**  
A **Suffix Tree** is a compacted trie containing all suffixes of a string:
- Suffix Trees achieve $O(m)$ search time and $O(n)$ construction time.
- However, Suffix Trees have massive memory overhead (typically $20 \dots 45$ bytes per input character due to node pointers and edge labels).
- A **Suffix Array** stores only integers ($4$ bytes per character), reducing memory by up to 80% while retaining nearly identical asymptotic search capability.

---

### Q35. How does MergeSort integrate into the ranking pipeline?
**Answer:**  
After raw matches are aggregated by document and scored, we implement a classical recursive **MergeSort** algorithm to sort the $K$ matching documents:
- Time Complexity: $O(K \log K)$ in the best, average, and worst cases.
- Stability: MergeSort is stable, preserving relative document order when scores are identical.
- Comparisons are explicitly tracked and displayed in the frontend to demonstrate DSA compliance.
