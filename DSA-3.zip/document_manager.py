"""
Document Manager and Global-to-Document Position Mapping.

Time Complexity:
- Document lookup by position: O(log D) via Binary Search over document boundaries.
- Snippet generation: O(1) string slicing.

Core DSA Concept:
In a full-text search engine across multiple documents, the entire corpus
is concatenated into one contiguous string separated by unique delimiter sentinels.
When the Suffix Array finds a match at global index G, a binary search over
document boundary ranges maps G -> (Document ID, Document Title, Local Offset).
"""

import os
from typing import List, Dict, Any, Tuple, Optional


class Document:
    """Represents a single indexed text document."""

    def __init__(self, doc_id: int, title: str, filename: str, content: str):
        self.doc_id = doc_id
        self.title = title
        self.filename = filename
        self.content = content
        self.char_count = len(content)
        self.word_count = len(content.split())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "doc_id": self.doc_id,
            "title": self.title,
            "filename": self.filename,
            "char_count": self.char_count,
            "word_count": self.word_count,
            "preview": self.content[:200] + ("..." if len(self.content) > 200 else "")
        }


class DocumentManager:
    """
    Manages corpus documents, concatenates texts with sentinels,
    and maps global suffix array match positions to local document offsets.
    """

    DELIMITER = "\x00"  # ASCII 0 sentinel: lexicographically smaller than any printable char

    def __init__(self, doc_dir: Optional[str] = None):
        self.doc_dir = doc_dir
        self.documents: List[Document] = []
        self.concatenated_text: str = ""
        self.normalized_text: str = ""  # Lowercase for case-insensitive searching
        # Boundaries: List of tuples (global_start, global_end, doc_id)
        self.boundaries: List[Tuple[int, int, int]] = []
        self.doc_map: Dict[int, Document] = {}

        if doc_dir and os.path.exists(doc_dir):
            self.load_directory(doc_dir)

    def load_directory(self, doc_dir: str):
        """Loads and sorts all .txt files from the specified directory."""
        self.doc_dir = doc_dir
        self.documents = []
        self.boundaries = []
        self.doc_map = {}

        files = sorted([f for f in os.listdir(doc_dir) if f.endswith(".txt")])
        doc_id = 1
        for f in files:
            full_path = os.path.join(doc_dir, f)
            with open(full_path, "r", encoding="utf-8") as file:
                lines = file.readlines()
                first_line = lines[0].strip() if lines else f
                content = "".join(lines)
                doc = Document(doc_id=doc_id, title=first_line, filename=f, content=content)
                self.documents.append(doc)
                self.doc_map[doc_id] = doc
                doc_id += 1

        self._build_concatenated_corpus()

    def add_document(self, title: str, filename: str, content: str) -> int:
        """Manually adds a document to the collection."""
        doc_id = len(self.documents) + 1
        doc = Document(doc_id=doc_id, title=title, filename=filename, content=content)
        self.documents.append(doc)
        self.doc_map[doc_id] = doc
        self._build_concatenated_corpus()
        return doc_id

    def _build_concatenated_corpus(self):
        """
        Concatenates all documents using the delimiter sentinel.
        Records (start, end, doc_id) boundaries for binary search mapping.
        """
        parts = []
        self.boundaries = []
        cur_pos = 0

        for doc in self.documents:
            start_pos = cur_pos
            parts.append(doc.content)
            cur_pos += len(doc.content)
            end_pos = cur_pos
            self.boundaries.append((start_pos, end_pos, doc.doc_id))

            # Add delimiter between documents
            parts.append(self.DELIMITER)
            cur_pos += len(self.DELIMITER)

        self.concatenated_text = "".join(parts)
        self.normalized_text = self.concatenated_text.lower()

    def map_position_to_document(self, global_pos: int, match_len: int) -> Optional[Tuple[Document, int]]:
        """
        Uses Binary Search over document boundaries in O(log D) time.
        
        Returns:
            (Document, local_char_offset) if match is fully contained within one document,
            or None if the match spans across the delimiter sentinel.
        """
        if not self.boundaries:
            return None

        # Binary Search over boundaries list
        low = 0
        high = len(self.boundaries) - 1

        while low <= high:
            mid = (low + high) // 2
            start, end, doc_id = self.boundaries[mid]

            if start <= global_pos < end:
                # Check that the entire match length stays within this document
                if global_pos + match_len <= end:
                    local_offset = global_pos - start
                    return self.doc_map[doc_id], local_offset
                else:
                    # Match straddles delimiter boundary
                    return None
            elif global_pos < start:
                high = mid - 1
            else:
                low = mid + 1

        return None

    def generate_snippet(self, doc_id: int, local_offset: int, match_len: int, context_chars: int = 50) -> str:
        """
        Extracts a textual snippet around the match and marks the matching substring.
        """
        doc = self.doc_map.get(doc_id)
        if not doc:
            return ""

        content = doc.content
        start_ctx = max(0, local_offset - context_chars)
        end_ctx = min(len(content), local_offset + match_len + context_chars)

        prefix = "..." if start_ctx > 0 else ""
        suffix = "..." if end_ctx < len(content) else ""

        before_match = content[start_ctx:local_offset]
        matched_str = content[local_offset:local_offset + match_len]
        after_match = content[local_offset + match_len:end_ctx]

        # Clean newlines for clean display in snippets
        before_clean = before_match.replace("\n", " ")
        matched_clean = matched_str.replace("\n", " ")
        after_clean = after_match.replace("\n", " ")

        return f"{prefix}{before_clean}<mark>{matched_clean}</mark>{after_clean}{suffix}"
