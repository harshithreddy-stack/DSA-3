"""
Performance Analysis and Inverted Index Comparison Suite.

Measures:
1. Suffix Array Construction Time
2. Kasai LCP Construction Time
3. Total Index Construction Time
4. Query Latencies (Min, Max, Average across multiple trials)
5. Character comparisons (Standard Binary Search vs LCP-Accelerated)
6. Suffix Array vs Inverted Index Comparison across Query Types:
   - Exact Word Search
   - Prefix Search
   - Substring Search
   - Multi-word Phrase Search
"""

import time
import os
import sys
from typing import List, Dict, Any
from .search_engine import SearchEngine
from .binary_search import standard_binary_search, lcp_accelerated_binary_search


class BenchmarkRunner:
    """Runs automated benchmarks and comparative evaluations."""

    DEFAULT_TEST_QUERIES = [
        ("algorithm", "substring"),
        ("data", "substring"),
        ("process", "substring"),
        ("machine learning", "phrase"),
        ("operating system", "phrase"),
        ("comp", "prefix"),
        ("net", "prefix"),
        ("struct", "substring"),
        ("gorith", "substring"),  # Pure intra-word substring
        ("artificial intelligence", "phrase"),
        ("memory", "substring"),
        ("nonexistentwordxyz", "substring")  # Miss test
    ]

    def __init__(self, search_engine: SearchEngine):
        self.engine = search_engine

    def run_query_latency_benchmark(self, trials: int = 10) -> List[Dict[str, Any]]:
        """
        Runs multiple iterations for each test query and calculates
        Minimum, Maximum, and Average latency.
        """
        results = []

        for query, q_type in self.DEFAULT_TEST_QUERIES:
            latencies = []
            matches_count = 0
            doc_matches_count = 0

            # Run multiple trials for statistical rigor
            for _ in range(trials):
                t0 = time.perf_counter()
                res = self.engine.search(query, search_type=q_type, use_lcp_accel=True)
                elapsed_ms = (time.perf_counter() - t0) * 1000.0
                latencies.append(elapsed_ms)
                matches_count = res["total_matches"]
                doc_matches_count = res["document_matches_count"]

            results.append({
                "query": query,
                "type": q_type,
                "matches": matches_count,
                "matching_docs": doc_matches_count,
                "trials": trials,
                "min_latency_ms": round(min(latencies), 4),
                "max_latency_ms": round(max(latencies), 4),
                "avg_latency_ms": round(sum(latencies) / len(latencies), 4)
            })

        return results

    def compare_standard_vs_lcp_search(self) -> List[Dict[str, Any]]:
        """
        Directly compares Standard Binary Search vs LCP-Accelerated Binary Search
        in terms of character comparisons and execution speed.
        """
        text = self.engine.doc_manager.normalized_text
        sa = self.engine.suffix_array_obj.get_suffix_array()
        lcp_obj = self.engine.lcp_obj

        comparison_results = []
        sample_queries = [
            "algorithm",
            "machine learning",
            "artificial intelligence",
            "operating system",
            "data structures",
            "dynamic programming",
            "concurrency",
            "relational database"
        ]

        for q in sample_queries:
            q_norm = q.lower()

            # 1. Standard Binary Search
            t0 = time.perf_counter()
            std_res = standard_binary_search(text, sa, q_norm)
            std_time_ms = (time.perf_counter() - t0) * 1000.0

            # 2. LCP-Accelerated Binary Search
            t1 = time.perf_counter()
            lcp_res = lcp_accelerated_binary_search(text, sa, lcp_obj, q_norm)
            lcp_time_ms = (time.perf_counter() - t1) * 1000.0

            saved_comps = max(0, std_res.comparisons - lcp_res.comparisons)
            pct_saved = round((saved_comps / max(1, std_res.comparisons)) * 100.0, 1)

            comparison_results.append({
                "query": q,
                "std_comparisons": std_res.comparisons,
                "lcp_comparisons": lcp_res.comparisons,
                "comparisons_saved": saved_comps,
                "percent_saved": f"{pct_saved}%",
                "std_time_ms": round(std_time_ms, 4),
                "lcp_time_ms": round(lcp_time_ms, 4)
            })

        return comparison_results

    def compare_suffix_array_vs_inverted_index(self) -> Dict[str, Any]:
        """
        Performs comprehensive empirical comparison between Suffix Array and Inverted Index.
        """
        inv_index = self.engine.inverted_index
        inv_stats = inv_index.get_statistics()
        sa_stats = self.engine.get_statistics()

        # Compare on distinct query categories
        test_cases = [
            ("Exact Word", "algorithm"),
            ("Prefix", "comp"),
            ("Substring (Intra-word)", "gorith"),
            ("Phrase", "machine learning")
        ]

        query_comparisons = []
        for category, query in test_cases:
            # Suffix Array measurement
            t0 = time.perf_counter()
            sa_res = self.engine.search(query, search_type="substring", use_lcp_accel=True)
            sa_time_ms = (time.perf_counter() - t0) * 1000.0

            # Inverted Index measurement
            t1 = time.perf_counter()
            if category == "Exact Word":
                inv_res = inv_index.search_exact_word(query)
            elif category == "Prefix":
                inv_res = inv_index.search_prefix(query)
            elif category == "Substring (Intra-word)":
                inv_res = inv_index.search_substring(query)
            else:  # Phrase
                inv_res = inv_index.search_phrase(query)
            inv_time_ms = (time.perf_counter() - t1) * 1000.0

            query_comparisons.append({
                "category": category,
                "query": query,
                "sa_latency_ms": round(sa_time_ms, 4),
                "sa_matches": sa_res["total_matches"],
                "inv_latency_ms": round(inv_time_ms, 4),
                "inv_matches": inv_res.get("matches_count", 0),
                "inv_notes": (
                    "Instant O(1) hash lookup" if category == "Exact Word"
                    else "O(V) lexicon scan needed" if category in ["Prefix", "Substring (Intra-word)"]
                    else "Positional intersection"
                ),
                "sa_notes": (
                    "O(m + log n) binary search across entire corpus"
                )
            })

        return {
            "construction_comparison": {
                "suffix_array_build_time_ms": sa_stats["total_build_time_ms"],
                "sa_details": f"SA: {sa_stats['sa_build_time_ms']}ms, LCP: {sa_stats['lcp_build_time_ms']}ms",
                "inverted_index_build_time_ms": inv_stats["build_time_ms"],
                "sa_memory_bytes": sa_stats["sa_memory_size_bytes"],
                "inverted_index_memory_bytes": inv_stats["memory_size_bytes"]
            },
            "queries": query_comparisons,
            "architectural_tradeoffs": [
                {
                    "dimension": "Arbitrary Substring Search",
                    "suffix_array": "Native O(m log n) support for any substring or character sequence",
                    "inverted_index": "Requires expensive O(V) full vocabulary scan or n-gram expansion"
                },
                {
                    "dimension": "Exact Word Search",
                    "suffix_array": "O(m log n) binary search",
                    "inverted_index": "Instant O(1) average hash table lookup"
                },
                {
                    "dimension": "Phrase Search",
                    "suffix_array": "O(m log n) direct single continuous string match",
                    "inverted_index": "O(P1 + P2) multi-postings list positional intersection"
                },
                {
                    "dimension": "Index Storage Complexity",
                    "suffix_array": "Fixed O(n) integers for SA + LCP",
                    "inverted_index": "Variable O(Total tokens) with postings pointers and positions"
                }
            ]
        }

    def generate_full_report(self) -> Dict[str, Any]:
        """Runs all benchmarks and aggregates complete diagnostic data."""
        return {
            "statistics": self.engine.get_statistics(),
            "query_latency": self.run_query_latency_benchmark(trials=5),
            "binary_search_comparison": self.compare_standard_vs_lcp_search(),
            "inverted_index_comparison": self.compare_suffix_array_vs_inverted_index()
        }


if __name__ == "__main__":
    docs_path = os.path.join(os.path.dirname(__file__), "..", "data", "documents")
    engine = SearchEngine(docs_path)
    benchmarker = BenchmarkRunner(engine)
    report = benchmarker.generate_full_report()

    print("=== FULL-TEXT SEARCH ENGINE BENCHMARK REPORT ===")
    print(f"Total Documents: {report['statistics']['document_count']}")
    print(f"Corpus Size: {report['statistics']['total_characters']} characters")
    print(f"Suffix Array Build Time: {report['statistics']['sa_build_time_ms']} ms")
    print(f"Kasai LCP Build Time: {report['statistics']['lcp_build_time_ms']} ms")
    print(f"Total SA Index Time: {report['statistics']['total_build_time_ms']} ms")
    print(f"Inverted Index Time: {report['statistics']['inverted_index_stats']['build_time_ms']} ms\n")

    print("--- Query Latencies ---")
    for q in report["query_latency"]:
        print(f"Query '{q['query']}' ({q['type']}): Avg {q['avg_latency_ms']} ms (Min: {q['min_latency_ms']} ms, Max: {q['max_latency_ms']} ms) | Matches: {q['matches']}")

    print("\n--- Standard vs LCP-Accelerated Comparisons ---")
    for c in report["binary_search_comparison"]:
        print(f"Query '{c['query']}': Std comps={c['std_comparisons']}, LCP comps={c['lcp_comparisons']} (Saved {c['comparisons_saved']}, {c['percent_saved']})")
